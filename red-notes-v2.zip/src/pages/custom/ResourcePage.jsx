import React, { useState, useEffect } from 'react';
import { ExternalLink, Search, Plus, X, Pencil, Check } from 'lucide-react';
import { persistGet, persistSet } from '../../lib/persistentStorage';

const colorOptions = [
  { value: 'cyan',   label: 'Cyan',   text: 'text-cyan-400',    bg: 'bg-cyan-500',    dot: 'bg-cyan-400',    header: 'text-cyan-400 border-cyan-500/30' },
  { value: 'green',  label: 'Green',  text: 'text-emerald-400', bg: 'bg-emerald-500', dot: 'bg-emerald-400', header: 'text-emerald-400 border-emerald-500/30' },
  { value: 'red',    label: 'Red',    text: 'text-red-400',     bg: 'bg-red-500',     dot: 'bg-red-400',     header: 'text-red-400 border-red-500/30' },
  { value: 'purple', label: 'Purple', text: 'text-purple-400',  bg: 'bg-purple-500',  dot: 'bg-purple-400',  header: 'text-purple-400 border-purple-500/30' },
  { value: 'orange', label: 'Orange', text: 'text-orange-400',  bg: 'bg-orange-500',  dot: 'bg-orange-400',  header: 'text-orange-400 border-orange-500/30' },
  { value: 'pink',   label: 'Pink',   text: 'text-pink-400',    bg: 'bg-pink-500',    dot: 'bg-pink-400',    header: 'text-pink-400 border-pink-500/30' },
  { value: 'blue',   label: 'Blue',   text: 'text-blue-400',    bg: 'bg-blue-500',    dot: 'bg-blue-400',    header: 'text-blue-400 border-blue-500/30' },
  { value: 'yellow', label: 'Yellow', text: 'text-yellow-400',  bg: 'bg-yellow-500',  dot: 'bg-yellow-400',  header: 'text-yellow-400 border-yellow-500/30' },
];

export default function ResourcePage({ pageKey }) {
  const defaultMeta = { title: 'My Resources', titleColor: 'cyan', description: '' };

  const localLoad = (key, fb) => { try { const s = localStorage.getItem(key); return s ? JSON.parse(s) : fb; } catch { return fb; } };

  const [meta, setMetaRaw] = useState(() => localLoad(`redops_meta_${pageKey}`, defaultMeta));
  const [categories, setCategoriesRaw] = useState(() => localLoad(`redops_resource_${pageKey}`, []));
  const [editingMeta, setEditingMeta] = useState(false);
  const [draftMeta, setDraftMeta] = useState(meta);
  const [search, setSearch] = useState('');

  const [addingCategory, setAddingCategory] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [newCatColor, setNewCatColor] = useState('cyan');
  const [addingLinkTo, setAddingLinkTo] = useState(null);
  const [newLinkName, setNewLinkName] = useState('');
  const [newLinkDesc, setNewLinkDesc] = useState('');
  const [newLinkUrl, setNewLinkUrl] = useState('');

  useEffect(() => {
    persistGet(`redops_meta_${pageKey}`).then(val => { if (val) setMetaRaw(val); });
    persistGet(`redops_resource_${pageKey}`).then(val => { if (val) setCategoriesRaw(val); });
  }, [pageKey]);

  const updateMeta = (m) => { setMetaRaw(m); persistSet(`redops_meta_${pageKey}`, m); };
  const updateCategories = (c) => { setCategoriesRaw(c); persistSet(`redops_resource_${pageKey}`, c); };

  const handleSaveMeta = () => { updateMeta(draftMeta); setEditingMeta(false); };

  const handleAddCategory = () => {
    if (!newCatName.trim()) return;
    updateCategories([...categories, { name: newCatName, color: newCatColor, links: [] }]);
    setNewCatName(''); setNewCatColor('cyan'); setAddingCategory(false);
  };

  const handleDeleteCategory = (i) => updateCategories(categories.filter((_, idx) => idx !== i));

  const handleAddLink = (catIndex) => {
    if (!newLinkName.trim() || !newLinkUrl.trim()) return;
    const updated = [...categories];
    updated[catIndex].links.push({ name: newLinkName, desc: newLinkDesc, url: newLinkUrl });
    updateCategories(updated);
    setNewLinkName(''); setNewLinkDesc(''); setNewLinkUrl(''); setAddingLinkTo(null);
  };

  const handleDeleteLink = (catIndex, linkIndex) => {
    const updated = [...categories];
    updated[catIndex].links.splice(linkIndex, 1);
    updateCategories(updated);
  };

  const titleColorClass = colorOptions.find(c => c.value === meta.titleColor)?.text || 'text-cyan-400';

  const filtered = search.trim()
    ? categories.map(cat => ({
        ...cat,
        links: cat.links.filter(l =>
          l.name.toLowerCase().includes(search.toLowerCase()) ||
          l.desc.toLowerCase().includes(search.toLowerCase())
        )
      })).filter(cat => cat.links.length > 0)
    : categories;

  const totalLinks = categories.reduce((sum, c) => sum + c.links.length, 0);

  return (
    <div className="space-y-10">
      {/* Header */}
      <div className="text-center mb-10">
        {!editingMeta ? (
          <div>
            <h1 className="text-3xl md:text-5xl font-bold font-mono tracking-tight">
              <span className={titleColorClass}>{meta.title}</span>
            </h1>
            {meta.description && (
              <p className="text-slate-500 font-mono text-sm mt-3">{meta.description}</p>
            )}
            {totalLinks > 0 && (
              <p className="text-slate-600 font-mono text-xs mt-1">{totalLinks} links across {categories.length} categories</p>
            )}
            <button
              onClick={() => { setDraftMeta(meta); setEditingMeta(true); }}
              className="mt-4 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 text-xs font-mono transition-all"
            >
              <Pencil className="w-3 h-3" /> Edit Header
            </button>
          </div>
        ) : (
          <div className="bg-[#0d1117] border border-slate-800 rounded-xl p-6 max-w-xl mx-auto text-left space-y-4">
            <h3 className="text-sm font-mono font-bold text-slate-300 uppercase tracking-wider">Edit Page Header</h3>
            <div>
              <label className="block text-xs font-mono text-slate-500 mb-1">TITLE</label>
              <input type="text" value={draftMeta.title} onChange={e => setDraftMeta({ ...draftMeta, title: e.target.value })}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded text-slate-200 font-mono text-sm focus:outline-none focus:border-slate-500" />
            </div>
            <div>
              <label className="block text-xs font-mono text-slate-500 mb-2">TITLE COLOR</label>
              <div className="flex flex-wrap gap-2">
                {colorOptions.map(opt => (
                  <button key={opt.value} onClick={() => setDraftMeta({ ...draftMeta, titleColor: opt.value })}
                    className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-mono transition-all border ${draftMeta.titleColor === opt.value ? 'border-slate-400 bg-slate-700 text-slate-100' : 'border-slate-700 bg-slate-800 text-slate-400 hover:border-slate-500'}`}>
                    <div className={`w-2.5 h-2.5 rounded-full ${opt.bg}`} />{opt.label}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-xs font-mono text-slate-500 mb-1">DESCRIPTION</label>
              <textarea value={draftMeta.description} onChange={e => setDraftMeta({ ...draftMeta, description: e.target.value })}
                placeholder="Brief description..." className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded text-slate-200 placeholder-slate-500 font-mono text-xs focus:outline-none focus:border-slate-500 h-20" />
            </div>
            <div className="flex gap-2">
              <button onClick={() => setEditingMeta(false)} className="flex-1 px-4 py-2 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700 transition-colors font-mono text-sm">Cancel</button>
              <button onClick={handleSaveMeta} className="flex-1 px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700 transition-colors font-mono text-sm font-semibold flex items-center justify-center gap-1">
                <Check className="w-4 h-4" /> Save
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Search + Add Category */}
      <div className="flex flex-col sm:flex-row gap-3 items-center max-w-2xl mx-auto">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search resources..."
            className="w-full bg-[#111827] border border-slate-700/50 rounded-lg pl-10 pr-4 py-2.5 text-sm font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-slate-500 transition-colors" />
        </div>
        <button onClick={() => setAddingCategory(true)}
          className="px-4 py-2.5 bg-cyan-600 hover:bg-cyan-700 text-white text-xs font-mono rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap">
          <Plus className="w-3.5 h-3.5" /> Add Category
        </button>
      </div>

      {/* Categories Grid */}
      {filtered.length === 0 && !search && (
        <div className="text-center py-16 text-slate-600 font-mono text-sm">
          No categories yet — click "Add Category" to get started
        </div>
      )}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filtered.map((cat, catIdx) => {
          const colorOpt = colorOptions.find(c => c.value === cat.color) || colorOptions[0];
          return (
            <div key={catIdx} className="bg-[#0d1117] border border-slate-800/50 rounded-xl overflow-hidden">
              <div className={`px-4 py-3 border-b-2 ${colorOpt.header} flex items-center justify-between`}>
                <div>
                  <span className="font-mono text-xs font-bold tracking-widest uppercase">{cat.name}</span>
                  <span className="ml-2 text-slate-600 font-mono text-xs">({cat.links.length})</span>
                </div>
                <button onClick={() => handleDeleteCategory(catIdx)} className="text-slate-600 hover:text-red-400 transition-colors p-0.5">
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="p-3 space-y-1.5">
                {cat.links.map((link, linkIdx) => (
                  <div key={linkIdx} className="flex items-start gap-1 group">
                    <a href={link.url} target="_blank" rel="noopener noreferrer"
                      className="flex items-start gap-3 px-3 py-2.5 rounded-lg hover:bg-slate-800/40 transition-all flex-1 min-w-0">
                      <span className={`mt-1.5 w-1.5 h-1.5 rounded-full flex-shrink-0 ${colorOpt.dot}`} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-sm font-semibold text-slate-200 group-hover:text-white transition-colors">{link.name}</span>
                          <ExternalLink className="w-3 h-3 text-slate-600 group-hover:text-slate-400 flex-shrink-0 transition-colors" />
                        </div>
                        {link.desc && <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">{link.desc}</p>}
                      </div>
                    </a>
                    <button onClick={() => handleDeleteLink(catIdx, linkIdx)}
                      className="text-slate-700 hover:text-red-400 transition-colors p-1.5 opacity-0 group-hover:opacity-100 flex-shrink-0 mt-1">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
                {addingLinkTo === catIdx ? (
                  <div className="px-2 py-2 space-y-2 border border-slate-700 rounded-lg bg-slate-800/30">
                    <input type="text" value={newLinkName} onChange={e => setNewLinkName(e.target.value)} placeholder="Name *" autoFocus
                      className="w-full px-2 py-1.5 bg-slate-800 border border-slate-700 rounded text-slate-200 placeholder-slate-500 font-mono text-xs focus:outline-none focus:border-slate-500" />
                    <input type="text" value={newLinkDesc} onChange={e => setNewLinkDesc(e.target.value)} placeholder="Description (optional)"
                      className="w-full px-2 py-1.5 bg-slate-800 border border-slate-700 rounded text-slate-200 placeholder-slate-500 font-mono text-xs focus:outline-none focus:border-slate-500" />
                    <input type="text" value={newLinkUrl} onChange={e => setNewLinkUrl(e.target.value)} placeholder="URL *"
                      className="w-full px-2 py-1.5 bg-slate-800 border border-slate-700 rounded text-slate-200 placeholder-slate-500 font-mono text-xs focus:outline-none focus:border-slate-500"
                      onKeyDown={e => { if (e.key === 'Enter') handleAddLink(catIdx); if (e.key === 'Escape') { setAddingLinkTo(null); setNewLinkName(''); setNewLinkDesc(''); setNewLinkUrl(''); } }} />
                    <div className="flex gap-1.5">
                      <button onClick={() => handleAddLink(catIdx)} className="flex-1 px-2 py-1 bg-cyan-600 hover:bg-cyan-700 text-white text-xs font-mono rounded transition-colors">Add</button>
                      <button onClick={() => { setAddingLinkTo(null); setNewLinkName(''); setNewLinkDesc(''); setNewLinkUrl(''); }}
                        className="flex-1 px-2 py-1 bg-slate-700 hover:bg-slate-600 text-slate-300 text-xs font-mono rounded transition-colors">Cancel</button>
                    </div>
                  </div>
                ) : (
                  <button onClick={() => setAddingLinkTo(catIdx)}
                    className="w-full px-3 py-2 text-xs font-mono text-slate-500 hover:text-slate-300 border border-dashed border-slate-700 rounded hover:border-slate-500 transition-colors flex items-center gap-1.5 justify-center">
                    <Plus className="w-3 h-3" /> Add Link
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Category Modal */}
      {addingCategory && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-[#0d1117] border border-slate-800 rounded-lg p-6 max-w-sm w-full mx-4 space-y-4">
            <h3 className="text-lg font-mono font-bold text-slate-200">New Category</h3>
            <div>
              <label className="block text-xs font-mono text-slate-500 mb-1">NAME</label>
              <input type="text" value={newCatName} onChange={e => setNewCatName(e.target.value)} placeholder="e.g., Reference Docs" autoFocus
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-200 placeholder-slate-500 font-mono text-sm focus:outline-none focus:border-slate-500"
                onKeyDown={e => e.key === 'Enter' && handleAddCategory()} />
            </div>
            <div>
              <label className="block text-xs font-mono text-slate-500 mb-2">COLOR</label>
              <div className="flex flex-wrap gap-2">
                {colorOptions.map(opt => (
                  <button key={opt.value} onClick={() => setNewCatColor(opt.value)}
                    className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-mono transition-all border ${newCatColor === opt.value ? 'border-slate-400 bg-slate-700 text-slate-100' : 'border-slate-700 bg-slate-800 text-slate-400 hover:border-slate-500'}`}>
                    <div className={`w-2.5 h-2.5 rounded-full ${opt.bg}`} />{opt.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex gap-2">
              <button onClick={() => { setAddingCategory(false); setNewCatName(''); setNewCatColor('cyan'); }}
                className="flex-1 px-4 py-2 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700 transition-colors font-mono text-sm">Cancel</button>
              <button onClick={handleAddCategory}
                className="flex-1 px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700 transition-colors font-mono text-sm font-semibold">Create</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}