import React, { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Shield, ChevronRight, Plus, Trash2, Sparkles, Loader2 } from 'lucide-react';
import { generateLocalPageTemplate } from '@/lib/localPageTemplates';
import { persistGet, persistSet, persistDelete } from '@/lib/persistentStorage';

function dedupePages(pages) {
  const seen = new Set();
  return pages.filter(p => {
    if (seen.has(p.key)) return false;
    seen.add(p.key);
    return true;
  });
}

function localLoad(key, fallback) {
  try {
    const s = localStorage.getItem(key);
    return s ? JSON.parse(s) : fallback;
  } catch { return fallback; }
}

const crtoItems = [
  { name: 'OPSEC', page: 'C2OPSEC', color: 'text-cyan-400' },
  { name: 'Reconnaissance', page: 'Reconnaissance', color: 'text-cyan-400' },
  { name: 'Initial Compromise', page: 'InitialCompromise', color: 'text-emerald-400' },
  { name: 'Wi-Fi', page: 'WiFi', color: 'text-cyan-400' },
  { name: 'Web Applications', page: 'WebApplications', color: 'text-blue-400' },
  { name: 'Execution', page: 'Execution', color: 'text-emerald-400' },
  { name: 'Host Operations', page: 'HostOperations', color: 'text-emerald-400' },
  { name: 'Privilege Escalation', page: 'PrivilegeEscalation', color: 'text-red-400' },
  { name: 'Credential Access', page: 'CredentialAccess', color: 'text-red-400' },
  { name: 'Lateral Movement', page: 'LateralMovement', color: 'text-orange-400' },
  { name: 'Active Directory', page: 'ADAttacks', color: 'text-pink-400' },
  { name: 'Domain Dominance', page: 'DomainDominance', color: 'text-yellow-400' },
  { name: 'Defense Evasion', page: 'EvasionCRTO', color: 'text-orange-400' },
];

const levelItems = [
  { name: 'WinAPIs', page: 'WindowsAPIs', color: 'text-emerald-400' },
  { name: 'Process Injection', page: 'ProcessInjection', color: 'text-red-400' },
  { name: 'Malware', page: 'Malware', color: 'text-red-400' },
  { name: 'ASR & WDAC', page: 'ASRAndWDAC', color: 'text-orange-400' },
  { name: 'EDR Evasion', page: 'EDREvasion', color: 'text-red-400' },
  { name: 'DevOps', page: 'DevOps', color: 'text-blue-400' },
  { name: 'AI / ML', page: 'AIML', color: 'text-purple-400' },
  { name: 'Tools', page: 'Tools', color: 'text-yellow-400' },
];

const builtinNavItems = [
  { name: 'Home', page: 'RedTeamHome', color: 'text-slate-300' },
  ...crtoItems,
  ...levelItems,
];



// Context menu component
function NavContextMenu({ x, y, label, onDelete, onClose }) {
  const ref = useRef(null);

  useEffect(() => {
    const handle = (e) => {
      if (ref.current && !ref.current.contains(e.target)) onClose();
    };
    document.addEventListener('mousedown', handle);
    return () => document.removeEventListener('mousedown', handle);
  }, [onClose]);

  return (
    <div
      ref={ref}
      className="fixed z-[200] bg-[#0d1117] border border-slate-700 rounded-lg shadow-xl py-1 min-w-[160px]"
      style={{ top: y, left: x }}
    >
      <div className="px-3 py-1.5 text-[11px] font-mono text-slate-500 border-b border-slate-800 mb-1">{label}</div>
      <button
        onClick={onDelete}
        className="w-full text-left px-3 py-2 text-sm font-mono text-red-400 hover:bg-red-500/10 transition-colors flex items-center gap-2"
      >
        <Trash2 className="w-3.5 h-3.5" /> Delete Page
      </button>
    </div>
  );
}

export default function Layout({ children, currentPageName }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [customPages, setCustomPagesState] = useState(() => dedupePages(localLoad('redops_custom_pages', [])));
  const [addPageOpen, setAddPageOpen] = useState(false);
  const [newPageName, setNewPageName] = useState('');
  const [newPageType, setNewPageType] = useState('notes');
  const [contextMenu, setContextMenu] = useState(null);
  const [hiddenPages, setHiddenPagesState] = useState(() => localLoad('redops_hidden_pages', []));
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState('');
  const [aiResult, setAiResult] = useState(null);

  // Nav ordering: builtins + custom pages combined
  const [navOrder, setNavOrderRaw] = useState(() => {
    const saved = localLoad('redops_nav_order', null);
    return [...new Set(saved || builtinNavItems.map(i => i.page))];
  });
  const navDragIndex = useRef(null);

  // Load from DB on mount, overriding localStorage if DB has fresher data
  useEffect(() => {
    persistGet('redops_custom_pages').then(val => {
      if (val) setCustomPagesState(dedupePages(val));
    });
    persistGet('redops_hidden_pages').then(val => {
      if (val) setHiddenPagesState(val);
    });
    persistGet('redops_nav_order').then(val => {
      if (val) setNavOrderRaw([...new Set(val)]);
    });
  }, []);

  const setCustomPages = (val) => {
    const next = typeof val === 'function' ? val(customPages) : val;
    const deduped = dedupePages(next);
    setCustomPagesState(deduped);
    persistSet('redops_custom_pages', deduped);
  };

  const setHiddenPages = (val) => {
    const next = typeof val === 'function' ? val(hiddenPages) : val;
    setHiddenPagesState(next);
    persistSet('redops_hidden_pages', next);
  };

  const setNavOrder = (val) => {
    const raw = typeof val === 'function' ? val(navOrder) : val;
    const next = [...new Set(raw)];
    setNavOrderRaw(next);
    persistSet('redops_nav_order', next);
  };

  // Ensure new builtin pages and custom pages are in the order list
  useEffect(() => {
    setNavOrder(prev => {
      let updated = [...prev];
      let changed = false;
      builtinNavItems.forEach(item => {
        if (!updated.includes(item.page)) { updated.push(item.page); changed = true; }
      });
      customPages.forEach(p => {
        if (!updated.includes(p.key)) { updated.push(p.key); changed = true; }
      });
      return changed ? updated : prev;
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customPages.length]);

  const handleAiGenerate = async () => {
    if (!aiPrompt.trim()) return;
    setAiLoading(true);
    setAiError('');
    try {
      const result = generateLocalPageTemplate(aiPrompt);
      setNewPageName(result.pageName || '');
      setNewPageType(result.pageType || 'notes');
      setAiResult(result);
    } catch (e) {
      setAiError('Template generation failed. Try again.');
    } finally {
      setAiLoading(false);
    }
  };

  const pageTypes = [
    { value: 'notes', label: 'Notes', desc: 'Map + technique cards' },
    { value: 'resource', label: 'Resources', desc: 'Categorized links' },
    { value: 'text', label: 'Text', desc: 'Free-form text sections' },
    { value: 'home', label: 'Home', desc: 'Full methodology dashboard' },
  ];

  const handleAddPage = () => {
    const name = newPageName.trim();
    if (!name) return;
    // Clean slug: lowercase, spaces to hyphens, only alphanumeric + hyphens
    let slug = name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
    // Avoid collisions with existing pages or builtin routes — always make unique
    const existingKeys = customPages.map(p => p.key);
    const builtinRoutes = builtinNavItems.map(i => i.page.toLowerCase());
    let baseSlug = slug;
    let counter = 1;
    while (existingKeys.includes(slug) || builtinRoutes.includes(slug)) {
      slug = baseSlug + '-' + counter++;
    }
    persistSet(`redops_pagetype_${slug}`, newPageType);

    // Seed AI-generated content before navigating
    if (aiResult) {
      if ((newPageType === 'notes' || newPageType === 'home') && aiResult.columns?.length) {
        const seededCols = aiResult.columns.map(col => ({
          header: col.header,
          color: col.color || 'cyan',
          nodes: (col.nodes || []).map((n, i) => ({ title: n.title, subtitle: n.subtitle || '', tags: [], id: `ai-node-${Date.now()}-${i}` }))
        }));
        persistSet(`redops_columns_${slug}`, seededCols);
      }
      if (newPageType === 'resource' && aiResult.categories?.length) {
        const seededCats = aiResult.categories.map((cat, ci) => ({
          name: cat.name,
          color: ['cyan','green','purple','orange','pink','blue','yellow','red'][ci % 8],
          links: (cat.items || []).map(item => ({ name: item.title, desc: '', url: item.url || '#' }))
        }));
        persistSet(`redops_resource_${slug}`, seededCats);
      }
      if (newPageType === 'text' && aiResult.sections?.length) {
        const seededSections = aiResult.sections.map((s, i) => ({ title: s.title || '', body: s.body || '', id: `ai-s-${Date.now()}-${i}` }));
        persistSet(`redops_text_${slug}`, seededSections);
      }
      persistSet(`redops_meta_${slug}`, { title: name, titleColor: 'cyan', description: '', tags: [] });
    }

    const page = { name, key: slug };
    const updated = [...customPages, page];
    setCustomPages(updated);
    saveCustomPages(updated);
    setNavOrder(prev => [...prev, slug]);
    setNewPageName('');
    setNewPageType('notes');
    setAiPrompt('');
    setAiError('');
    setAiResult(null);
    setAddPageOpen(false);
    window.location.href = `/note/${slug}`;
  };

  const handleCloseAddPage = () => {
    setAddPageOpen(false);
    setNewPageName('');
    setNewPageType('notes');
    setAiPrompt('');
    setAiError('');
    setAiResult(null);
  };

  const handleDeletePage = (key) => {
    const updated = customPages.filter(p => p.key !== key);
    setCustomPages(updated);
    setNavOrder(prev => prev.filter(k => k !== key));
    setContextMenu(null);
    // Delete all associated data from DB + localStorage permanently
    const keysToDelete = [
      `redops_pagetype_${key}`,
      `redops_meta_${key}`,
      `redops_columns_${key}`,
      `redops_cards_${key}`,
      `redops_order_${key}`,
      `redops_hidden_${key}`,
      `redops_resource_${key}`,
      `redops_text_${key}`,
    ];
    keysToDelete.forEach(k => persistDelete(k));
    if (currentPageName === `note/${key}`) window.location.href = '/';
  };

  const handleHideBuiltinPage = (page) => {
    const updated = [...hiddenPages, page];
    setHiddenPages(updated);
    saveHiddenPages(updated);
    setContextMenu(null);
    if (currentPageName === page) window.location.href = '/';
  };

  const openContextMenu = (e, label, pageKey = null, builtinPage = null) => {
    e.preventDefault();
    // Keep menu inside viewport
    const x = Math.min(e.clientX, window.innerWidth - 180);
    const y = Math.min(e.clientY, window.innerHeight - 100);
    setContextMenu({ x, y, label, pageKey, builtinPage });
  };

  return (
    <div className="min-h-screen bg-[#0a0e1a]">
      {/* Top Nav */}
      <nav className="sticky top-0 z-50 bg-[#0a0e1a]/90 backdrop-blur-xl border-b border-slate-800/50">
        <div className="max-w-[1440px] mx-auto px-4 md:px-6">
          <div className="flex items-center justify-between h-14">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2.5 group mr-8">
              <Shield className="w-5 h-5 text-red-500 group-hover:text-red-400 transition-colors" />
              <span className="font-mono font-bold text-sm hidden sm:block">
                <span className="text-white">RED</span> <span className="text-red-500">|</span> <span className="text-white">NOTES</span>
              </span>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-1 overflow-x-auto flex-1 px-4" style={{ scrollbarWidth: 'thin' }}>
              {navOrder.map((key) => {
                const builtin = builtinNavItems.find(i => i.page === key);
                const custom = customPages.find(p => p.key === key);
                if (builtin && !hiddenPages.includes(key)) {
                  return (
                    <Link
                      key={key}
                      to={key === 'RedTeamHome' ? '/Home' : `/${key}`}
                      draggable
                      onDragStart={() => { navDragIndex.current = navOrder.indexOf(key); }}
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={() => {
                        const from = navDragIndex.current;
                        const to = navOrder.indexOf(key);
                        if (from !== null && from !== to) {
                          setNavOrder(prev => {
                            const next = [...prev];
                            const [moved] = next.splice(from, 1);
                            next.splice(to, 0, moved);
                            return next;
                          });
                        }
                        navDragIndex.current = null;
                      }}
                      onContextMenu={(e) => openContextMenu(e, builtin.name, null, key)}
                      className={`px-3 py-1.5 rounded-md text-xs font-mono font-medium transition-all whitespace-nowrap cursor-grab ${
                        currentPageName === key || (key === 'RedTeamHome' && currentPageName === 'Home')
                          ? `${builtin.color} bg-white/5`
                          : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
                      }`}
                    >
                      {builtin.name}
                    </Link>
                  );
                }
                if (custom) {
                  return (
                    <Link
                      key={key}
                      to={`/note/${key}`}
                      draggable
                      onDragStart={() => { navDragIndex.current = navOrder.indexOf(key); }}
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={() => {
                        const from = navDragIndex.current;
                        const to = navOrder.indexOf(key);
                        if (from !== null && from !== to) {
                          setNavOrder(prev => {
                            const next = [...prev];
                            const [moved] = next.splice(from, 1);
                            next.splice(to, 0, moved);
                            return next;
                          });
                        }
                        navDragIndex.current = null;
                      }}
                      onContextMenu={(e) => openContextMenu(e, custom.name, key)}
                      className={`px-3 py-1.5 rounded-md text-xs font-mono font-medium transition-all whitespace-nowrap cursor-grab ${
                        currentPageName === `note/${key}`
                          ? 'text-slate-300 bg-white/5'
                          : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
                      }`}
                    >
                      {custom.name}
                    </Link>
                  );
                }
                return null;
              })}
              {/* Add Page button */}
              <button
                onClick={() => setAddPageOpen(true)}
                className="ml-2 flex-shrink-0 px-2.5 py-1.5 rounded-md text-xs font-mono font-medium text-slate-600 hover:text-slate-300 hover:bg-white/5 transition-all flex items-center gap-1 border border-dashed border-slate-700 hover:border-slate-500"
              >
                <Plus className="w-3 h-3" /> New Page
              </button>
            </div>

            {/* Mobile Toggle */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden text-slate-400 hover:text-slate-200 transition-colors"
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Nav */}
        {mobileOpen && (
          <div className="md:hidden border-t border-slate-800/50 bg-[#0a0e1a]/95 backdrop-blur-xl">
            <div className="px-4 py-3 space-y-1">
              {navOrder.map((key) => {
                const builtin = builtinNavItems.find(i => i.page === key);
                const custom = customPages.find(p => p.key === key);
                if (builtin && !hiddenPages.includes(key)) {
                  return (
                    <Link key={key} to={key === 'RedTeamHome' ? '/Home' : `/${key}`} onClick={() => setMobileOpen(false)}
                      onContextMenu={(e) => openContextMenu(e, builtin.name, null, key)}
                      className={`flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-mono transition-all ${currentPageName === key ? `${builtin.color} bg-white/5` : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'}`}>
                      <ChevronRight className="w-3 h-3" />{builtin.name}
                    </Link>
                  );
                }
                if (custom) {
                  return (
                    <Link key={key} to={`/note/${key}`} onClick={() => setMobileOpen(false)}
                      onContextMenu={(e) => openContextMenu(e, custom.name, key)}
                      className={`flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-mono transition-all ${currentPageName === `note/${key}` ? 'text-slate-300 bg-white/5' : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'}`}>
                      <ChevronRight className="w-3 h-3" />{custom.name}
                    </Link>
                  );
                }
                return null;
              })}
              <button onClick={() => { setMobileOpen(false); setAddPageOpen(true); }}
                className="flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-mono text-slate-500 hover:text-slate-300 hover:bg-white/5 transition-all w-full border border-dashed border-slate-700">
                <Plus className="w-3 h-3" /> New Page
              </button>
            </div>
          </div>
        )}
      </nav>

      {/* Context Menu */}
      {contextMenu && (
        <NavContextMenu
          x={contextMenu.x}
          y={contextMenu.y}
          label={contextMenu.label}
          onDelete={() => contextMenu.pageKey ? handleDeletePage(contextMenu.pageKey) : handleHideBuiltinPage(contextMenu.builtinPage)}
          onClose={() => setContextMenu(null)}
        />
      )}

      {/* Add Page Modal */}
      {addPageOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[100]">
          <div className="bg-[#0d1117] border border-slate-800 rounded-lg p-6 max-w-sm w-full mx-4 space-y-4 max-h-[90vh] overflow-y-auto">
            <h3 className="text-lg font-mono font-bold text-slate-200">New Page</h3>

            {/* AI Template Generator */}
            <div className="border border-slate-700/50 rounded-lg p-3 bg-slate-800/30">
              <label className="block text-xs font-mono text-slate-400 mb-1.5 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-purple-400" /> TEMPLATE HELPER — describe what you need
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={aiPrompt}
                  onChange={e => setAiPrompt(e.target.value)}
                  placeholder="e.g., cloud attack techniques"
                  className="flex-1 px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-200 placeholder-slate-500 font-mono text-xs focus:outline-none focus:border-purple-500/50"
                  onKeyDown={e => e.key === 'Enter' && handleAiGenerate()}
                />
                <button
                  onClick={handleAiGenerate}
                  disabled={!aiPrompt.trim() || aiLoading}
                  className="px-3 py-2 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white rounded-lg transition-colors font-mono text-xs flex items-center gap-1"
                >
                  {aiLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                  {aiLoading ? '' : 'Generate'}
                </button>
              </div>
              {aiError && <p className="text-red-400 text-xs font-mono mt-1">{aiError}</p>}
              {aiResult && !aiLoading && (
                <p className="text-emerald-400 text-xs font-mono mt-1">
                  ✓ Prepared: <span className="text-slate-300">{aiResult.pageType}</span> page with {
                    aiResult.columns?.length ? `${aiResult.columns.length} columns` :
                    aiResult.categories?.length ? `${aiResult.categories.length} categories` :
                    aiResult.sections?.length ? `${aiResult.sections.length} sections` : 'content'
                  }
                </p>
              )}
            </div>

            <div>
              <label className="block text-xs font-mono text-slate-500 mb-1">PAGE NAME</label>
              <input
                type="text"
                value={newPageName}
                onChange={e => setNewPageName(e.target.value)}
                placeholder="e.g., Cloud Attacks"
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-200 placeholder-slate-500 font-mono text-sm focus:outline-none focus:border-slate-500"
                autoFocus
                onKeyDown={e => { if (e.key === 'Enter') handleAddPage(); if (e.key === 'Escape') handleCloseAddPage(); }}
              />
            </div>
            <div>
              <label className="block text-xs font-mono text-slate-500 mb-2">PAGE TYPE</label>
              <div className="space-y-2">
                {pageTypes.map(pt => (
                  <button key={pt.value} onClick={() => setNewPageType(pt.value)}
                    className={`w-full text-left px-3 py-2.5 rounded-lg border transition-all font-mono ${newPageType === pt.value ? 'border-cyan-500/50 bg-cyan-500/10 text-slate-200' : 'border-slate-700 bg-slate-800 text-slate-400 hover:border-slate-500'}`}>
                    <div className="text-sm font-semibold">{pt.label}</div>
                    <div className="text-xs text-slate-500 mt-0.5">{pt.desc}</div>
                  </button>
                ))}
              </div>
            </div>
            <div className="flex gap-2">
              <button onClick={handleCloseAddPage} className="flex-1 px-4 py-2 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700 transition-colors font-mono text-sm">Cancel</button>
              <button onClick={handleAddPage} disabled={!newPageName.trim()} className="flex-1 px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-mono text-sm font-semibold">Create</button>
            </div>
          </div>
        </div>
      )}

      {/* Content */}
      <main className="max-w-[1440px] mx-auto px-4 md:px-6 py-8 md:py-12">
        {children}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/50 py-6">
        <div className="max-w-[1440px] mx-auto px-4 md:px-6">
          <p className="text-center text-slate-600 font-mono text-xs">
            Red Team Operations Reference
          </p>
        </div>
      </footer>
    </div>
  );
}