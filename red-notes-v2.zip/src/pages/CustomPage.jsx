import React from 'react';
import NotesPage from './custom/NotesPage';
import ResourcePage from './custom/ResourcePage';
import TextPage from './custom/TextPage';
import HomePage from './custom/HomePage';

function getPageType(pageKey) {
  try {
    const s = localStorage.getItem(`redops_pagetype_${pageKey}`);
    return s || 'notes';
  } catch { return 'notes'; }
}

export default function CustomPage({ pageKey }) {
  const type = getPageType(pageKey);

  if (type === 'resource') return <ResourcePage pageKey={pageKey} />;
  if (type === 'text') return <TextPage pageKey={pageKey} />;
  if (type === 'home') return <HomePage pageKey={pageKey} />;
  return <NotesPage pageKey={pageKey} />;
}