import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
// pages.config removed — using explicit routes instead
import { BrowserRouter as Router, Route, Routes, useParams } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/components/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';

// CRTO pages
import { Navigate } from 'react-router-dom';

function isPageHidden(page) {
  try {
    const s = localStorage.getItem('redops_hidden_pages');
    const hidden = s ? JSON.parse(s) : [];
    return hidden.includes(page);
  } catch { return false; }
}

function GuardedPage({ page, children }) {
  if (isPageHidden(page)) return <Navigate to="/" replace />;
  return children;
}

import C2OPSEC from './pages/C2OPSEC';
import Reconnaissance from './pages/Reconnaissance';
import InitialCompromise from './pages/InitialCompromise';
import WiFi from './pages/WiFi';
import HostOperations from './pages/HostOperations';
import PrivilegeEscalation from './pages/PrivilegeEscalation';
import CredentialAccess from './pages/CredentialAccess';
import LateralMovement from './pages/LateralMovement';
import ADAttacks from './pages/ADAttacks';
import DomainDominance from './pages/DomainDominance';
import Evasion from './pages/EvasionCRTO';
import WebApplications from './pages/WebApplications';
import Execution from './pages/Execution';
// CRTL pages
// C2Infrastructure merged into C2OPSEC
import WindowsAPIs from './pages/WindowsAPIs';
import ProcessInjection from './pages/ProcessInjection';
import Malware from './pages/Malware';

import ASRAndWDAC from './pages/ASRAndWDAC';
import EDREvasion from './pages/EDREvasion';
import DevOps from './pages/DevOps';
import AIML from './pages/AIML';

import Tools from './pages/Tools';
import Layout from './pages/Layout.jsx';
import Home from './pages/Home.jsx';
import RedTeamHome from './pages/RedTeamHome.jsx';
import CustomPage from './pages/CustomPage.jsx';

const LayoutWrapper = ({ children, currentPageName }) => 
  <Layout currentPageName={currentPageName}>{children}</Layout>;

const CustomPageWrapper = () => {
  const { pageKey } = useParams();
  return (
    <LayoutWrapper currentPageName={`note/${pageKey}`}>
      <CustomPage pageKey={pageKey} />
    </LayoutWrapper>
  );
};

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/" element={
        <LayoutWrapper currentPageName="Home">
          <Home />
        </LayoutWrapper>
      } />
      <Route path="/Home" element={
        <LayoutWrapper currentPageName="Home">
          <RedTeamHome />
        </LayoutWrapper>
      } />
      {/* CRTO pages */}
      <Route path="/C2OPSEC" element={<GuardedPage page="C2OPSEC"><LayoutWrapper currentPageName="C2OPSEC"><C2OPSEC /></LayoutWrapper></GuardedPage>} />
      <Route path="/Reconnaissance" element={<GuardedPage page="Reconnaissance"><LayoutWrapper currentPageName="Reconnaissance"><Reconnaissance /></LayoutWrapper></GuardedPage>} />
      <Route path="/InitialCompromise" element={<GuardedPage page="InitialCompromise"><LayoutWrapper currentPageName="InitialCompromise"><InitialCompromise /></LayoutWrapper></GuardedPage>} />
      <Route path="/WiFi" element={<GuardedPage page="WiFi"><LayoutWrapper currentPageName="WiFi"><WiFi /></LayoutWrapper></GuardedPage>} />
      <Route path="/HostOperations" element={<GuardedPage page="HostOperations"><LayoutWrapper currentPageName="HostOperations"><HostOperations /></LayoutWrapper></GuardedPage>} />
      <Route path="/PrivilegeEscalation" element={<GuardedPage page="PrivilegeEscalation"><LayoutWrapper currentPageName="PrivilegeEscalation"><PrivilegeEscalation /></LayoutWrapper></GuardedPage>} />
      <Route path="/CredentialAccess" element={<GuardedPage page="CredentialAccess"><LayoutWrapper currentPageName="CredentialAccess"><CredentialAccess /></LayoutWrapper></GuardedPage>} />
      <Route path="/LateralMovement" element={<GuardedPage page="LateralMovement"><LayoutWrapper currentPageName="LateralMovement"><LateralMovement /></LayoutWrapper></GuardedPage>} />
      <Route path="/ADAttacks" element={<GuardedPage page="ADAttacks"><LayoutWrapper currentPageName="ADAttacks"><ADAttacks /></LayoutWrapper></GuardedPage>} />
      <Route path="/DomainDominance" element={<GuardedPage page="DomainDominance"><LayoutWrapper currentPageName="DomainDominance"><DomainDominance /></LayoutWrapper></GuardedPage>} />
      <Route path="/EvasionCRTO" element={<GuardedPage page="EvasionCRTO"><LayoutWrapper currentPageName="EvasionCRTO"><Evasion /></LayoutWrapper></GuardedPage>} />
      <Route path="/WebApplications" element={<GuardedPage page="WebApplications"><LayoutWrapper currentPageName="WebApplications"><WebApplications /></LayoutWrapper></GuardedPage>} />
      <Route path="/Execution" element={<GuardedPage page="Execution"><LayoutWrapper currentPageName="Execution"><Execution /></LayoutWrapper></GuardedPage>} />
      <Route path="/WindowsAPIs" element={<GuardedPage page="WindowsAPIs"><LayoutWrapper currentPageName="WindowsAPIs"><WindowsAPIs /></LayoutWrapper></GuardedPage>} />
      <Route path="/ProcessInjection" element={<GuardedPage page="ProcessInjection"><LayoutWrapper currentPageName="ProcessInjection"><ProcessInjection /></LayoutWrapper></GuardedPage>} />
      <Route path="/Malware" element={<GuardedPage page="Malware"><LayoutWrapper currentPageName="Malware"><Malware /></LayoutWrapper></GuardedPage>} />
      <Route path="/ASRAndWDAC" element={<GuardedPage page="ASRAndWDAC"><LayoutWrapper currentPageName="ASRAndWDAC"><ASRAndWDAC /></LayoutWrapper></GuardedPage>} />
      <Route path="/EDREvasion" element={<GuardedPage page="EDREvasion"><LayoutWrapper currentPageName="EDREvasion"><EDREvasion /></LayoutWrapper></GuardedPage>} />
      <Route path="/DevOps" element={<GuardedPage page="DevOps"><LayoutWrapper currentPageName="DevOps"><DevOps /></LayoutWrapper></GuardedPage>} />
      <Route path="/AIML" element={<GuardedPage page="AIML"><LayoutWrapper currentPageName="AIML"><AIML /></LayoutWrapper></GuardedPage>} />
      <Route path="/Tools" element={<GuardedPage page="Tools"><LayoutWrapper currentPageName="Tools"><Tools /></LayoutWrapper></GuardedPage>} />
      <Route path="/note/:pageKey" element={<CustomPageWrapper />} />
      <Route path="/custom/:pageKey" element={<CustomPageWrapper />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App