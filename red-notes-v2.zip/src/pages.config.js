/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import Collection from './pages/Collection';
import CollectionExfil from './pages/CollectionExfil';
import Evasion from './pages/Evasion';
import Execution from './pages/Execution';
import Exfiltration from './pages/Exfiltration';
import Home from './pages/Home';
import Infrastructure from './pages/Infrastructure';
import InitialAccess from './pages/InitialAccess';
import Overview from './pages/Overview';
import PostExploitation from './pages/PostExploitation';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Collection": Collection,
    "CollectionExfil": CollectionExfil,
    "Evasion": Evasion,
    "Execution": Execution,
    "Exfiltration": Exfiltration,
    "Home": Home,
    "Infrastructure": Infrastructure,
    "InitialAccess": InitialAccess,
    "Overview": Overview,
    "PostExploitation": PostExploitation,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
    Layout: __Layout,
};