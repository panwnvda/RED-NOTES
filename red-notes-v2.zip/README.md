# Red Manual

This project is a standard Vite + React app and no longer depends on Base44 services, SDKs, plugins, or APIs.

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Notes

- Persistence is handled with browser localStorage.
- The page template generator is local and does not call any external API.
