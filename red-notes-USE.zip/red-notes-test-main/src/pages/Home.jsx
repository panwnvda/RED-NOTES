import React from 'react';
import { Shield, BookOpen, Layers, MousePointer, Plus, Edit3, Sparkles, FileText, Link, StickyNote, Download, Upload, FolderOpen } from 'lucide-react';

const features = [
  {
    icon: <Layers className="w-5 h-5 text-cyan-400" />,
    title: 'Methodology Map',
    desc: 'Organize attack techniques into a visual column-based map. Add columns, topics, and nested nodes to build your own custom TTPs reference.'
  },
  {
    icon: <FileText className="w-5 h-5 text-purple-400" />,
    title: 'Technique Cards',
    desc: 'Create detailed technique cards with overviews, step-by-step guides, and syntax-highlighted code blocks. Drag to reorder, click to edit.'
  },
  {
    icon: <Link className="w-5 h-5 text-blue-400" />,
    title: 'Resource Pages',
    desc: 'Curate categorized link collections — tools, references, CVEs, cheatsheets. Perfect for bookmarking during engagements.'
  },
  {
    icon: <Sparkles className="w-5 h-5 text-yellow-400" />,
    title: 'AI Template Generator',
    desc: 'Describe what you need and let AI pick the right page type and name — just click "+ New Page" in the nav.'
  },
  {
    icon: <MousePointer className="w-5 h-5 text-red-400" />,
    title: 'Drag & Drop',
    desc: 'Reorder technique cards and columns with drag-and-drop. Right-click any nav item to delete it from your sidebar.'
  },
];

const howToSteps = [
  {
    step: '01',
    title: 'Create a new page',
    desc: 'Click "+ New Page" in the navigation bar. Type a description and let AI suggest a page type, or pick one manually.',
    color: 'text-cyan-400',
    border: 'border-cyan-500/20',
  },
  {
    step: '02',
    title: 'Build your map',
    desc: 'On Notes or Home pages, add columns and topics to create a visual methodology map. Click "+ Add Column" and then "+ Add Topic" within each column.',
    color: 'text-emerald-400',
    border: 'border-emerald-500/20',
  },
  {
    step: '03',
    title: 'Add technique cards',
    desc: 'Click "+ Add Technique Card" to create detailed reference cards with overviews, numbered steps, and code blocks. Click the pencil icon to edit existing cards.',
    color: 'text-purple-400',
    border: 'border-purple-500/20',
  },
  {
    step: '04',
    title: 'Export your project',
    desc: 'Click the "Export" button in the top-right of the navbar. This downloads a .rednotes file to your computer — your complete project saved locally.',
    color: 'text-orange-400',
    border: 'border-orange-500/20',
  },
  {
    step: '05',
    title: 'Re-import to continue',
    desc: 'Next time, click "Import" and select your .rednotes file. Everything — pages, cards, maps, links — loads back instantly. Export again after each session.',
    color: 'text-red-400',
    border: 'border-red-500/20',
  },
];

export default function Home() {
  return (
    <div className="max-w-4xl mx-auto">

      {/* Hero */}
      <div className="text-center mb-16 pt-4">
        <div className="flex items-center justify-center gap-3 mb-6">
          <Shield className="w-10 h-10 text-red-500" />
          <h1 className="text-4xl md:text-5xl font-bold font-mono tracking-tight">
            <span className="text-white">RED</span> <span className="text-red-500">|</span> <span className="text-white">NOTES</span>
          </h1>
        </div>
        <p className="text-slate-400 font-mono text-base max-w-2xl mx-auto leading-relaxed">
          A personal knowledge management platform built for offensive security practitioners.
          Organize your TTPs, build methodology maps, and document techniques — all in one place.
        </p>
      </div>

      {/* What is RED | NOTES */}
      <div className="mb-16">
        <h2 className="text-xl font-bold font-mono text-slate-200 mb-4 flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-red-400" /> What is RED | NOTES?
        </h2>
        <div className="bg-[#0d1117] border border-slate-800/50 rounded-xl p-6 text-slate-400 font-mono text-sm leading-relaxed space-y-3">
          <p>
            RED | NOTES is a structured note-taking and knowledge management app designed for red teamers, penetration testers, and security researchers. It ships with a comprehensive built-in reference covering the full offensive security lifecycle — from reconnaissance to domain dominance.
          </p>
          <p>
            Every page in the sidebar is fully customizable. You can add your own columns, topics, and technique cards to any page, or create entirely new pages from scratch. Nothing is locked — the app is your personal ops notebook.
          </p>
          <p>
            Your work is saved as a <span className="text-cyan-400">.rednotes</span> file stored on your own machine — nothing is sent to any server. Use <span className="text-cyan-400">Export</span> (top-right) to save a snapshot, and <span className="text-cyan-400">Import</span> to pick up where you left off.
          </p>
        </div>
      </div>

      {/* Features */}
      <div className="mb-16">
        <h2 className="text-xl font-bold font-mono text-slate-200 mb-6 flex items-center gap-2">
          <Layers className="w-5 h-5 text-cyan-400" /> Features
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {features.map((f, i) => (
            <div key={i} className="bg-[#0d1117] border border-slate-800/50 rounded-xl p-5 flex gap-4">
              <div className="flex-shrink-0 mt-0.5">{f.icon}</div>
              <div>
                <p className="text-slate-200 font-mono font-semibold text-sm mb-1">{f.title}</p>
                <p className="text-slate-500 font-mono text-xs leading-relaxed">{f.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* How to use */}
      <div className="mb-16">
        <h2 className="text-xl font-bold font-mono text-slate-200 mb-6 flex items-center gap-2">
          <MousePointer className="w-5 h-5 text-emerald-400" /> How to Use
        </h2>
        <div className="space-y-4">
          {howToSteps.map((s, i) => (
            <div key={i} className={`bg-[#0d1117] border ${s.border} rounded-xl p-5 flex gap-5`}>
              <div className={`font-mono font-bold text-2xl ${s.color} flex-shrink-0 leading-none mt-0.5`}>{s.step}</div>
              <div>
                <p className={`font-mono font-semibold text-sm ${s.color} mb-1`}>{s.title}</p>
                <p className="text-slate-500 font-mono text-xs leading-relaxed">{s.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* File Workflow Banner */}
      <div className="mb-10">
        <div className="bg-[#0d1117] border border-slate-700/60 rounded-xl p-6 flex flex-col md:flex-row gap-6 items-start md:items-center">
          <div className="flex items-center gap-3 flex-shrink-0">
            <FolderOpen className="w-8 h-8 text-cyan-400" />
            <div>
              <p className="text-slate-200 font-mono font-semibold text-sm">File-based storage</p>
              <p className="text-slate-500 font-mono text-xs mt-0.5">Like Obsidian — your data lives in a file on your machine</p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 flex-1">
            <div className="flex items-start gap-3 flex-1 border border-slate-800 rounded-lg p-3">
              <Upload className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-emerald-400 font-mono font-semibold text-xs">Import</p>
                <p className="text-slate-500 font-mono text-xs mt-0.5">Click Import in the navbar and select your <span className="text-slate-300">.rednotes</span> file to load a project.</p>
              </div>
            </div>
            <div className="flex items-start gap-3 flex-1 border border-slate-800 rounded-lg p-3">
              <Download className="w-4 h-4 text-cyan-400 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-cyan-400 font-mono font-semibold text-xs">Export</p>
                <p className="text-slate-500 font-mono text-xs mt-0.5">Click Export after making changes to save a new <span className="text-slate-300">.rednotes</span> snapshot locally.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Tips */}
      <div className="mb-8">
        <h2 className="text-xl font-bold font-mono text-slate-200 mb-4 flex items-center gap-2">
          <Edit3 className="w-5 h-5 text-yellow-400" /> Quick Tips
        </h2>
        <div className="bg-[#0d1117] border border-slate-800/50 rounded-xl p-6">
          <ul className="space-y-3 font-mono text-xs text-slate-400">
            <li className="flex gap-2"><span className="text-yellow-400 flex-shrink-0">→</span> Hover over a technique card to reveal the <span className="text-slate-300 mx-1">✎ edit</span> and <span className="text-slate-300 mx-1">✕ delete</span> buttons.</li>
            <li className="flex gap-2"><span className="text-yellow-400 flex-shrink-0">→</span> Drag cards by the grip handle on the left to reorder them.</li>
            <li className="flex gap-2"><span className="text-yellow-400 flex-shrink-0">→</span> Right-click any nav item to delete it from your sidebar permanently.</li>
            <li className="flex gap-2"><span className="text-yellow-400 flex-shrink-0">→</span> Use the AI generator in "+ New Page" to auto-select the best page type.</li>
            <li className="flex gap-2"><span className="text-yellow-400 flex-shrink-0">→</span> Always export after a session — your .rednotes file is the source of truth.</li>
            <li className="flex gap-2"><span className="text-yellow-400 flex-shrink-0">→</span> Code blocks in technique cards support syntax highlighting for bash, PowerShell, Python, C#, and more.</li>
          </ul>
        </div>
      </div>

    </div>
  );
}