import React, { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Shield, ChevronRight, Plus, Trash2, Sparkles, Loader2, ImagePlus } from 'lucide-react';
import { persistGet, persistSet, persistDelete } from '@/lib/persistentStorage'; // persistSet used for page creation/nav
import ImportExportControls from '@/components/ImportExportControls';

function dedupePages(pages) {
  const seen = new Set();
  return pages.filter(p => {
    if (seen.has(p.key)) return false;
    seen.add(p.key);
    return true;
  });
}

function localLoad(key, fallback) {
  try {
    const s = localStorage.getItem(key);
    return s ? JSON.parse(s) : fallback;
  } catch { return fallback; }
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error('Failed to read file.'));
    reader.readAsDataURL(file);
  });
}

function localGeneratePageTemplate(prompt, imageProvided = false) {
  const text = (prompt || '').trim();
  const normalized = text.toLowerCase();
  const colors = ['cyan', 'green', 'red', 'purple', 'orange', 'pink', 'blue', 'yellow'];

  const words = text
    .replace(/[^a-zA-Z0-9\s-]/g, ' ')
    .split(/\s+/)
    .filter(Boolean);

  const pageName = words.slice(0, 3).join(' ') || (imageProvided ? 'Image Notes' : 'New Notes');

  const resourceHints = ['resource', 'resources', 'links', 'bookmark', 'bookmarks', 'reference', 'references', 'tools', 'tooling'];
  const isResource = resourceHints.some(h => normalized.includes(h));
  const pageType = isResource ? 'resource' : 'notes';

  const topic = pageName;

  if (pageType === 'resource') {
    return {
      pageName,
      pageType,
      categories: [
        {
          name: 'Core References',
          items: [
            { title: `${topic} Overview`, url: '#' },
            { title: `${topic} Documentation`, url: '#' },
            { title: `${topic} Notes`, url: '#' },
          ],
        },
        {
          name: 'Further Reading',
          items: [
            { title: `${topic} Examples`, url: '#' },
            { title: `${topic} Research`, url: '#' },
            { title: `${topic} Checklist`, url: '#' },
          ],
        },
      ],
    };
  }

  return {
    pageName,
    pageType,
    columns: [
      {
        header: 'Overview',
        color: colors[0],
        nodes: [
          { title: `${topic} Summary`, subtitle: 'High-level view' },
          { title: 'Key Concepts', subtitle: 'Important ideas' },
          { title: 'Scope', subtitle: 'What this page covers' },
        ],
      },
      {
        header: 'Workflow',
        color: colors[1],
        nodes: [
          { title: 'Preparation', subtitle: 'Set up and prerequisites' },
          { title: 'Execution', subtitle: 'Main steps' },
          { title: 'Validation', subtitle: 'Check outcomes' },
        ],
      },
      {
        header: 'Follow Up',
        color: colors[2],
        nodes: [
          { title: 'Troubleshooting', subtitle: 'Common issues' },
          { title: 'Notes', subtitle: 'Useful reminders' },
          { title: 'Next Steps', subtitle: 'Where to go next' },
        ],
      },
    ],
  };
}

const builtinNavItems = [];



// Context menu component
function NavContextMenu({ x, y, label, onDelete, onClose }) {
  const ref = useRef(null);

  useEffect(() => {
    const handle = (e) => {
      if (ref.current && !ref.current.contains(e.target)) onClose();
    };
    document.addEventListener('mousedown', handle);
    return () => document.removeEventListener('mousedown', handle);
  }, [onClose]);

  return (
    <div
      ref={ref}
      className="fixed z-[200] bg-[#0d1117] border border-slate-700 rounded-lg shadow-xl py-1 min-w-[160px]"
      style={{ top: y, left: x }}
    >
      <div className="px-3 py-1.5 text-[11px] font-mono text-slate-500 border-b border-slate-800 mb-1">{label}</div>
      <button
        onClick={onDelete}
        className="w-full text-left px-3 py-2 text-sm font-mono text-red-400 hover:bg-red-500/10 transition-colors flex items-center gap-2"
      >
        <Trash2 className="w-3.5 h-3.5" /> Delete Page
      </button>
    </div>
  );
}

export default function Layout({ children, currentPageName }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [customPages, setCustomPagesState] = useState(() => dedupePages(localLoad('redops_custom_pages', [])));
  const [addPageOpen, setAddPageOpen] = useState(false);
  const [newPageName, setNewPageName] = useState('');
  const [newPageType, setNewPageType] = useState('notes');
  const [contextMenu, setContextMenu] = useState(null);
  const [hiddenPages, setHiddenPagesState] = useState(() => localLoad('redops_hidden_pages', []));
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState('');
  const [aiResult, setAiResult] = useState(null);
  const [aiImageUrl, setAiImageUrl] = useState(null);
  const [aiImageUploading, setAiImageUploading] = useState(false);
  const aiImageInputRef = useRef(null);

  // Nav ordering: builtins + custom pages combined
  const [navOrder, setNavOrderRaw] = useState(() => {
    const saved = localLoad('redops_nav_order', []);
    const savedList = Array.isArray(saved) ? saved : [];
    const customKeys = dedupePages(localLoad('redops_custom_pages', [])).map(p => p.key);
    return [...new Set(savedList.filter(key => customKeys.includes(key)))];
  });
  const navDragIndex = useRef(null);

  // Load from local persistent storage on mount
  useEffect(() => {
    persistGet('redops_custom_pages').then(val => {
      if (val) setCustomPagesState(dedupePages(val));
    });
    persistGet('redops_hidden_pages').then(val => {
      if (val) setHiddenPagesState(val);
    });
    persistGet('redops_nav_order').then(val => {
      const customKeys = dedupePages(localLoad('redops_custom_pages', [])).map(p => p.key);
      const savedList = Array.isArray(val) ? val : [];
      setNavOrderRaw([...new Set(savedList.filter(key => customKeys.includes(key)))]);
    });
  }, []);

  const setCustomPages = (val) => {
    const next = typeof val === 'function' ? val(customPages) : val;
    const deduped = dedupePages(next);
    setCustomPagesState(deduped);
    persistSet('redops_custom_pages', deduped);
  };

  const setHiddenPages = (val) => {
    const next = typeof val === 'function' ? val(hiddenPages) : val;
    setHiddenPagesState(next);
    persistSet('redops_hidden_pages', next);
  };

  const setNavOrder = (val) => {
    const raw = typeof val === 'function' ? val(navOrder) : val;
    const next = [...new Set(raw)];
    setNavOrderRaw(next);
    persistSet('redops_nav_order', next);
  };

  // Handle import: importProjectFile already wrote all data to storage, just reload
  const handleImport = () => {
    window.location.href = '/';
  };

  // Ensure new custom pages are added to the nav order (but don't force-add builtins — they may be intentionally absent after import)
  useEffect(() => {
    setNavOrder(prev => {
      let updated = [...prev];
      let changed = false;
      customPages.forEach(p => {
        if (!updated.includes(p.key)) { updated.push(p.key); changed = true; }
      });
      return changed ? updated : prev;
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customPages.length]);

  const handleAiImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setAiImageUploading(true);
    setAiError('');
    try {
      const dataUrl = await readFileAsDataUrl(file);
      setAiImageUrl(dataUrl);
    } catch {
      setAiError('Image upload failed.');
    }
    setAiImageUploading(false);
  };

  const handleAiGenerate = async () => {
    if (!aiPrompt.trim() && !aiImageUrl) return;
    setAiLoading(true);
    setAiError('');
    try {
      const result = localGeneratePageTemplate(aiPrompt, Boolean(aiImageUrl));
      setNewPageName(result.pageName || '');
      setNewPageType(result.pageType || 'notes');
      setAiResult(result);
    } catch {
      setAiError('Generation failed. Try again.');
    }
    setAiLoading(false);
  };

  const pageTypes = [
    { value: 'notes', label: 'Notes', desc: 'Column-based map + technique cards' },
    { value: 'resource', label: 'Resources', desc: 'Categorized link collections and references' },
    { value: 'home', label: 'Home', desc: 'Full dashboard with author card + map' },
  ];

  const handleAddPage = () => {
    const name = newPageName.trim();
    if (!name) return;
    // Clean slug: lowercase, spaces to hyphens, only alphanumeric + hyphens
    let slug = name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
    // Avoid collisions with existing pages or builtin routes — always make unique
    const existingKeys = customPages.map(p => p.key);
    const builtinRoutes = builtinNavItems.map(i => i.page.toLowerCase());
    let baseSlug = slug;
    let counter = 1;
    while (existingKeys.includes(slug) || builtinRoutes.includes(slug)) {
      slug = baseSlug + '-' + counter++;
    }
    persistSet(`redops_pagetype_${slug}`, newPageType);

    // Seed AI-generated content before navigating
    if (aiResult) {
      if ((newPageType === 'notes' || newPageType === 'home') && aiResult.columns?.length) {
        const seededCols = aiResult.columns.map(col => ({
          header: col.header,
          color: col.color || 'cyan',
          nodes: (col.nodes || []).map((n, i) => ({ title: n.title, subtitle: n.subtitle || '', tags: [], id: `ai-node-${Date.now()}-${i}` }))
        }));
        persistSet(`redops_columns_${slug}`, seededCols);
      }
      if (newPageType === 'resource' && aiResult.categories?.length) {
        const seededCats = aiResult.categories.map((cat, ci) => ({
          name: cat.name,
          color: ['cyan','green','purple','orange','pink','blue','yellow','red'][ci % 8],
          links: (cat.items || []).map(item => ({ name: item.title, desc: '', url: item.url || '#' }))
        }));
        persistSet(`redops_resource_${slug}`, seededCats);
      }
      persistSet(`redops_meta_${slug}`, { titleLeft: name, titleRight: '', titleLeftColor: 'cyan', title: name, titleColor: 'cyan', description: '', tags: [] });
      if (newPageType === 'home') {
        persistSet(`redops_homemeta_${slug}`, { titleLeft: name, titleRight: '', titleLeftColor: 'red', description: '', authorInitials: '', authorName: '', authorSub: '', authorTag: '' });
      }
      if (newPageType === 'text') {
        persistSet(`redops_text_${slug}`, { title: name, content: '' });
      }
    } else {
      // Seed meta for non-AI pages so the title shows the page name
      persistSet(`redops_meta_${slug}`, { titleLeft: name, titleRight: '', titleLeftColor: 'cyan', title: name, titleColor: 'cyan', description: '', tags: [] });
      if (newPageType === 'home') {
        persistSet(`redops_homemeta_${slug}`, { titleLeft: name, titleRight: '', titleLeftColor: 'red', description: '', authorInitials: '', authorName: '', authorSub: '', authorTag: '' });
      }
      if (newPageType === 'text') {
        persistSet(`redops_text_${slug}`, { title: name, content: '' });
      }
    }

    const page = { name, key: slug };
    const updated = [...customPages, page];
    setCustomPages(updated);
    setNavOrder(prev => [...prev, slug]);
    setNewPageName('');
    setNewPageType('notes');
    setAiPrompt('');
    setAiError('');
    setAiResult(null);
    setAiImageUrl(null);
    setAddPageOpen(false);
    window.location.href = `/note/${slug}`;
  };

  const handleCloseAddPage = () => {
    setAddPageOpen(false);
    setNewPageName('');
    setNewPageType('notes');
    setAiPrompt('');
    setAiError('');
    setAiResult(null);
    setAiImageUrl(null);
  };

  const handleDeletePage = (key) => {
    const updated = customPages.filter(p => p.key !== key);
    setCustomPages(updated);
    setNavOrder(prev => prev.filter(k => k !== key));
    setContextMenu(null);
    // Delete all associated data from DB + localStorage permanently
    const keysToDelete = [
      `redops_pagetype_${key}`,
      `redops_meta_${key}`,
      `redops_columns_${key}`,
      `redops_cards_${key}`,
      `redops_order_${key}`,
      `redops_hidden_${key}`,
      `redops_resource_${key}`,
      `redops_text_${key}`,
    ];
    keysToDelete.forEach(k => persistDelete(k));
    if (currentPageName === `note/${key}`) window.location.href = '/';
  };

  const handleHideBuiltinPage = (page) => {
    const updated = [...hiddenPages, page];
    setHiddenPages(updated);
    setContextMenu(null);
    if (currentPageName === page) window.location.href = '/';
  };

  const openContextMenu = (e, label, pageKey = null, builtinPage = null) => {
    e.preventDefault();
    // Keep menu inside viewport
    const x = Math.min(e.clientX, window.innerWidth - 180);
    const y = Math.min(e.clientY, window.innerHeight - 100);
    setContextMenu({ x, y, label, pageKey, builtinPage });
  };

  return (
    <div className="min-h-screen bg-[#0a0e1a]">
      {/* Top Nav */}
      <nav className="sticky top-0 z-50 bg-[#0a0e1a]/90 backdrop-blur-xl border-b border-slate-800/50">
        <div className="max-w-[1440px] mx-auto px-4 md:px-6">
          <div className="flex items-center justify-between h-14">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2.5 group mr-8">
              <Shield className="w-5 h-5 text-red-500 group-hover:text-red-400 transition-colors" />
              <span className="font-mono font-bold text-sm hidden sm:block">
                <span className="text-white">RED</span> <span className="text-red-500">|</span> <span className="text-white">NOTES</span>
              </span>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-1 overflow-x-auto flex-1 px-4" style={{ scrollbarWidth: 'thin' }}>
              {navOrder.map((key) => {
                const builtin = builtinNavItems.find(i => i.page === key);
                const custom = customPages.find(p => p.key === key);
                if (builtin && !hiddenPages.includes(key)) {
                  return (
                    <Link
                      key={key}
                      to={key === 'RedTeamHome' ? '/Home' : `/${key}`}
                      draggable
                      onDragStart={() => { navDragIndex.current = navOrder.indexOf(key); }}
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={() => {
                        const from = navDragIndex.current;
                        const to = navOrder.indexOf(key);
                        if (from !== null && from !== to) {
                          setNavOrder(prev => {
                            const next = [...prev];
                            const [moved] = next.splice(from, 1);
                            next.splice(to, 0, moved);
                            return next;
                          });
                        }
                        navDragIndex.current = null;
                      }}
                      onContextMenu={(e) => openContextMenu(e, builtin.name, null, key)}
                      className={`px-3 py-1.5 rounded-md text-xs font-mono font-medium transition-all whitespace-nowrap cursor-grab ${
                        currentPageName === key || (key === 'RedTeamHome' && currentPageName === 'Home')
                          ? `${builtin.color} bg-white/5`
                          : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
                      }`}
                    >
                      {builtin.name}
                    </Link>
                  );
                }
                if (custom) {
                  return (
                    <Link
                      key={key}
                      to={`/note/${key}`}
                      draggable
                      onDragStart={() => { navDragIndex.current = navOrder.indexOf(key); }}
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={() => {
                        const from = navDragIndex.current;
                        const to = navOrder.indexOf(key);
                        if (from !== null && from !== to) {
                          setNavOrder(prev => {
                            const next = [...prev];
                            const [moved] = next.splice(from, 1);
                            next.splice(to, 0, moved);
                            return next;
                          });
                        }
                        navDragIndex.current = null;
                      }}
                      onContextMenu={(e) => openContextMenu(e, custom.name, key)}
                      className={`px-3 py-1.5 rounded-md text-xs font-mono font-medium transition-all whitespace-nowrap cursor-grab ${
                        currentPageName === `note/${key}`
                          ? 'text-slate-300 bg-white/5'
                          : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
                      }`}
                    >
                      {custom.name}
                    </Link>
                  );
                }
                return null;
              })}
              {/* Add Page button */}
              <button
                onClick={() => setAddPageOpen(true)}
                className="ml-2 flex-shrink-0 px-2.5 py-1.5 rounded-md text-xs font-mono font-medium text-slate-600 hover:text-slate-300 hover:bg-white/5 transition-all flex items-center gap-1 border border-dashed border-slate-700 hover:border-slate-500"
              >
                <Plus className="w-3 h-3" /> New Page
              </button>
            </div>

            {/* Import / Export */}
            <div className="flex-shrink-0 ml-2">
              <ImportExportControls
                customPages={customPages}
                hiddenPages={hiddenPages}
                navOrder={navOrder}
                onImport={handleImport}
              />
            </div>

            {/* Mobile Toggle */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden text-slate-400 hover:text-slate-200 transition-colors ml-2"
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Nav */}
        {mobileOpen && (
          <div className="md:hidden border-t border-slate-800/50 bg-[#0a0e1a]/95 backdrop-blur-xl">
            <div className="px-4 py-3 space-y-1">
              {navOrder.map((key) => {
                const builtin = builtinNavItems.find(i => i.page === key);
                const custom = customPages.find(p => p.key === key);
                if (builtin && !hiddenPages.includes(key)) {
                  return (
                    <Link key={key} to={key === 'RedTeamHome' ? '/Home' : `/${key}`} onClick={() => setMobileOpen(false)}
                      onContextMenu={(e) => openContextMenu(e, builtin.name, null, key)}
                      className={`flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-mono transition-all ${currentPageName === key ? `${builtin.color} bg-white/5` : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'}`}>
                      <ChevronRight className="w-3 h-3" />{builtin.name}
                    </Link>
                  );
                }
                if (custom) {
                  return (
                    <Link key={key} to={`/note/${key}`} onClick={() => setMobileOpen(false)}
                      onContextMenu={(e) => openContextMenu(e, custom.name, key)}
                      className={`flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-mono transition-all ${currentPageName === `note/${key}` ? 'text-slate-300 bg-white/5' : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'}`}>
                      <ChevronRight className="w-3 h-3" />{custom.name}
                    </Link>
                  );
                }
                return null;
              })}
              <button onClick={() => { setMobileOpen(false); setAddPageOpen(true); }}
                className="flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-mono text-slate-500 hover:text-slate-300 hover:bg-white/5 transition-all w-full border border-dashed border-slate-700">
                <Plus className="w-3 h-3" /> New Page
              </button>
            </div>
          </div>
        )}
      </nav>

      {/* Context Menu */}
      {contextMenu && (
        <NavContextMenu
          x={contextMenu.x}
          y={contextMenu.y}
          label={contextMenu.label}
          onDelete={() => contextMenu.pageKey ? handleDeletePage(contextMenu.pageKey) : handleHideBuiltinPage(contextMenu.builtinPage)}
          onClose={() => setContextMenu(null)}
        />
      )}

      {/* Add Page Modal */}
      {addPageOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[100]">
          <div className="bg-[#0d1117] border border-slate-800 rounded-lg p-6 max-w-sm w-full mx-4 space-y-4 max-h-[90vh] overflow-y-auto">
            <h3 className="text-lg font-mono font-bold text-slate-200">New Page</h3>

            {/* AI Template Generator */}
            <div className="border border-slate-700/50 rounded-lg p-3 bg-slate-800/30">
              <label className="block text-xs font-mono text-slate-400 mb-1.5 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-purple-400" /> AI TEMPLATE — describe or upload an image
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={aiPrompt}
                  onChange={e => setAiPrompt(e.target.value)}
                  placeholder="e.g., cloud attack techniques"
                  className="flex-1 px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-200 placeholder-slate-500 font-mono text-xs focus:outline-none focus:border-purple-500/50"
                  onKeyDown={e => e.key === 'Enter' && handleAiGenerate()}
                />
                {/* Image upload */}
                <button
                  type="button"
                  onClick={() => aiImageInputRef.current?.click()}
                  disabled={aiImageUploading}
                  title="Upload image for AI context"
                  className={`px-2.5 py-2 rounded-lg border transition-colors font-mono text-xs flex items-center gap-1 ${aiImageUrl ? 'bg-purple-600/20 border-purple-500/50 text-purple-300' : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-500 hover:text-slate-200'}`}
                >
                  {aiImageUploading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ImagePlus className="w-3.5 h-3.5" />}
                </button>
                <input ref={aiImageInputRef} type="file" accept="image/*" className="hidden" onChange={handleAiImageUpload} />
                <button
                  onClick={handleAiGenerate}
                  disabled={(!aiPrompt.trim() && !aiImageUrl) || aiLoading}
                  className="px-3 py-2 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white rounded-lg transition-colors font-mono text-xs flex items-center gap-1"
                >
                  {aiLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                  {aiLoading ? '' : 'Generate'}
                </button>
              </div>
              {aiImageUrl && !aiImageUploading && (
                <div className="flex items-center gap-1.5 mt-1.5">
                  <span className="text-purple-400 text-xs font-mono">✓ Image attached</span>
                  <button onClick={() => setAiImageUrl(null)} className="text-slate-600 hover:text-red-400 transition-colors"><X className="w-3 h-3" /></button>
                </div>
              )}
              {aiError && <p className="text-red-400 text-xs font-mono mt-1">{aiError}</p>}
              {aiResult && !aiLoading && (
                <p className="text-emerald-400 text-xs font-mono mt-1">
                  ✓ Generated: <span className="text-slate-300">{aiResult.pageType}</span> page with {
                    aiResult.columns?.length ? `${aiResult.columns.length} columns` :
                    aiResult.categories?.length ? `${aiResult.categories.length} categories` : 'content'
                  }
                </p>
              )}
            </div>

            <div>
              <label className="block text-xs font-mono text-slate-500 mb-1">PAGE NAME</label>
              <input
                type="text"
                value={newPageName}
                onChange={e => setNewPageName(e.target.value)}
                placeholder="e.g., Cloud Attacks"
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-200 placeholder-slate-500 font-mono text-sm focus:outline-none focus:border-slate-500"
                autoFocus
                onKeyDown={e => { if (e.key === 'Enter') handleAddPage(); if (e.key === 'Escape') handleCloseAddPage(); }}
              />
            </div>
            <div>
              <label className="block text-xs font-mono text-slate-500 mb-2">PAGE TYPE</label>
              <div className="space-y-2">
                {pageTypes.map(pt => (
                  <button key={pt.value} onClick={() => setNewPageType(pt.value)}
                    className={`w-full text-left px-3 py-2.5 rounded-lg border transition-all font-mono ${newPageType === pt.value ? 'border-cyan-500/50 bg-cyan-500/10 text-slate-200' : 'border-slate-700 bg-slate-800 text-slate-400 hover:border-slate-500'}`}>
                    <div className="text-sm font-semibold">{pt.label}</div>
                    <div className="text-xs text-slate-500 mt-0.5">{pt.desc}</div>
                  </button>
                ))}
              </div>
            </div>
            <div className="flex gap-2">
              <button onClick={handleCloseAddPage} className="flex-1 px-4 py-2 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700 transition-colors font-mono text-sm">Cancel</button>
              <button onClick={handleAddPage} disabled={!newPageName.trim()} className="flex-1 px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-mono text-sm font-semibold">Create</button>
            </div>
          </div>
        </div>
      )}

      {/* Content */}
      <main className="max-w-[1440px] mx-auto px-4 md:px-6 py-8 md:py-12">
        {children}
      </main>


    </div>
  );
}