import { useState } from 'react';

/**
 * Persists page state (columns + cards) to localStorage.
 * Supports deleting built-in cards, custom cards, drag-to-reorder, and custom columns.
 */
export function usePageStorage(pageKey, defaultColumns, builtInCards = []) {
  const colKey    = `redops_columns_${pageKey}`;
  const cardKey   = `redops_cards_${pageKey}`;
  const orderKey  = `redops_order_${pageKey}`;
  const hiddenKey = `redops_hidden_${pageKey}`;

  const load = (key, fallback) => {
    try { const s = localStorage.getItem(key); return s ? JSON.parse(s) : fallback; }
    catch { return fallback; }
  };

  const [columns, setColumnsRaw] = useState(() => load(colKey, defaultColumns));
  const [customCards, setCustomCardsRaw] = useState(() => load(cardKey, []));
  const [hiddenIds, setHiddenIdsRaw] = useState(() => load(hiddenKey, [])); // built-in cards deleted by user
  const [cardOrder, setCardOrderRaw] = useState(() => load(orderKey, builtInCards.map(c => c.id)));

  const save = (key, value) => { try { localStorage.setItem(key, JSON.stringify(value)); } catch {} };

  const setColumns = (val) => {
    const next = typeof val === 'function' ? val(columns) : val;
    setColumnsRaw(next); save(colKey, next);
  };

  const setCustomCards = (val) => {
    const next = typeof val === 'function' ? val(customCards) : val;
    setCustomCardsRaw(next); save(cardKey, next);
  };

  const setHiddenIds = (val) => {
    const next = typeof val === 'function' ? val(hiddenIds) : val;
    setHiddenIdsRaw(next); save(hiddenKey, next);
  };

  const setCardOrder = (val) => {
    const next = typeof val === 'function' ? val(cardOrder) : val;
    setCardOrderRaw(next); save(orderKey, next);
  };

  // Merged ordered list
  const allCards = (() => {
    const builtInMap = {};
    builtInCards.forEach(c => { builtInMap[c.id] = { ...c, isBuiltIn: true }; });
    const customMap = {};
    customCards.forEach(c => { customMap[c.id] = { ...c, isBuiltIn: false }; });

    const orderedIds = [...cardOrder];
    // Add any new built-in cards not yet in order
    builtInCards.forEach(c => { if (!orderedIds.includes(c.id)) orderedIds.push(c.id); });
    // Add any new custom cards not yet in order
    customCards.forEach(c => { if (!orderedIds.includes(c.id)) orderedIds.push(c.id); });

    return orderedIds
      .filter(id => !hiddenIds.includes(id)) // filter deleted built-ins
      .map(id => builtInMap[id] || customMap[id])
      .filter(Boolean);
  })();

  const addCustomCard = (card) => {
    const newCard = { ...card, isBuiltIn: false };
    setCustomCards(prev => [...prev, newCard]);
    setCardOrder(prev => [...prev, card.id]);
  };

  const deleteCard = (id) => {
    // Check if it's a built-in card
    const isBuiltIn = builtInCards.some(c => c.id === id);
    if (isBuiltIn) {
      setHiddenIds(prev => [...prev, id]);
    } else {
      setCustomCards(prev => prev.filter(c => c.id !== id));
    }
    setCardOrder(prev => prev.filter(cid => cid !== id));
  };

  const reorderCards = (fromIndex, toIndex) => {
    // Build the current displayed order ids
    const currentIds = allCards.map(c => c.id);
    const [moved] = currentIds.splice(fromIndex, 1);
    currentIds.splice(toIndex, 0, moved);

    // Rebuild full order: new visible order + hidden ones at end
    const newOrder = [...currentIds, ...hiddenIds];
    setCardOrder(newOrder);
  };

  return { columns, setColumns, customCards, allCards, addCustomCard, deleteCard, reorderCards };
}