import React, { useState } from 'react';
import ArchitectureMap from '../components/ArchitectureMap';
import MapNode from '../components/MapNode';
import TechniqueCard from '../components/TechniqueCard';
import AddCardModal from '../components/AddCardModal';
import { Plus, X } from 'lucide-react';

const crtoColumns = [
  {
    header: 'OPSEC',
    color: 'cyan',
    nodes: [
      { title: 'C2', subtitle: 'Cobalt Strike • Sliver • listeners • pivots' },
      { title: 'Infrastructure', subtitle: 'Redirectors • Traffic Control • Beacons • Channels' },
      { title: 'Payloads', subtitle: 'BOFs • Shellcode Runners • OPSEC Principles' },
    ]
  },
  {
    header: 'RECONNAISSANCE',
    color: 'green',
    nodes: [
      { title: 'OSINT', subtitle: 'SOCK Puppets • DNS Records • Google Dorks • Social Media' },
      { title: 'Scanning', subtitle: 'Port Scanning • FTP • SSH • SMB • NFS • SMTP • SNMP • SQL' },
      { title: 'Packet Capture', subtitle: 'Wireshark • tshark • passive credential harvest' },
      { title: 'Internal Recon', subtitle: 'Domain Recon • BloodHound • PowerView • ADSearch' },
    ]
  },
  {
    header: 'INITIAL COMPROMISE',
    color: 'blue',
    nodes: [
      { title: 'Credential Attacks', subtitle: 'Password Spraying • OWA • O365 • Kerberos' },
      { title: 'Phishing', subtitle: 'AiTM • Evilginx • GoPhish • teamsphisher.py • Droplets' },
      { title: 'Payload Development', subtitle: 'Shellcode Development • msfvenom' },
      { title: 'Delivery', subtitle: 'VBA Macros • LNK • HTML Smuggling • Supply Chain • XLL' },
      { title: 'Physical & USB', subtitle: 'Rubber Ducky & HID • Malicious USB Drops' },
    ]
  },
  {
    header: 'WI-FI',
    color: 'cyan',
    nodes: [
      { title: 'Wi-Fi Reconnaissance', subtitle: 'airodump-ng • signal mapping • clients' },
      { title: 'WPA2 Attacks', subtitle: 'Handshake • PMKID • offline cracking' },
      { title: 'WPS Attacks', subtitle: 'Pixie Dust • PIN brute-force • reaver' },
      { title: 'WPA3 Attacks', subtitle: 'Dragonblood • SAE downgrade • fragmentation • timing side-channel • GCMP bypass • transition mode abuse' },
      { title: 'WPA Enterprise (802.1X)', subtitle: 'Rogue AP • EAP • RADIUS exploitation' },
      { title: 'Rogue AP & MITM', subtitle: 'Evil twin • traffic interception • SSL strip' },
      { title: 'Post-WiFi Access', subtitle: 'Internal recon • SMB relay • pivoting' },
    ]
  },
  {
    header: 'WEB APPLICATIONS',
    color: 'blue',
    nodes: [
      { title: 'Web Reconnaissance', subtitle: 'Enumeration • fingerprinting • mapping' },
      { title: 'Authentication', subtitle: 'Brute force • JWT • MFA bypass' },
      { title: 'Session Management', subtitle: 'Session fixation • CSRF • cookies' },
      { title: 'Authorization', subtitle: 'IDOR • BOLA • privilege escalation' },
      { title: 'Server-Side Attacks', subtitle: 'SQLi • RCE • SSRF • XXE • SSTI' },
      { title: 'Client-Side Attacks', subtitle: 'XSS • DOM XSS • CORS • CSP' },
      { title: 'API Attacks', subtitle: 'GraphQL • REST • mass assignment' },
      { title: 'Protocol Attacks', subtitle: 'Request smuggling • cache poison • verb tampering' },
      { title: 'Source Code Analysis', subtitle: 'SAST • taint analysis • dataflow' },
    ]
  },
  {
    header: 'EXECUTION',
    color: 'red',
    nodes: [
      { title: 'Shellcode & DLL', subtitle: 'Injection • reflective load • custom stagers' },
      { title: 'Managed Code', subtitle: 'Assembly loading • .NET • PowerShell' },
      { title: 'LOLBINs & Scripts', subtitle: 'Living off the land • LOLBAS • scripts' },
      { title: 'Remote & Token', subtitle: 'WMI • DCOM • token impersonation' },
    ]
  },
  {
    header: 'HOST OPERATIONS',
    color: 'purple',
    nodes: [
      { title: 'Host Recon', subtitle: 'Seatbelt • processes • sessions • Linux • macOS recon' },
      { title: 'User Persistence', subtitle: 'Startup • Task Scheduler • registry' },
      { title: 'Elevated Persistence', subtitle: 'Services • WMI • Linux systemd • macOS LaunchAgents' },
    ]
  },
  {
    header: 'PRIVILEGE ESCALATION',
    color: 'red',
    nodes: [
      { title: 'Service Exploits', subtitle: 'Weak perms • binary perms • unquoted • TCC/SIP bypass' },
      { title: 'Token & Secrets', subtitle: 'Token impersonation • DPAPI • SUID • sudo' },
      { title: 'Kernel Exploits', subtitle: 'DirtyPipe • PwnKit • PrintNightmare • EternalBlue' },
    ]
  },
  {
    header: 'CREDENTIAL ACCESS',
    color: 'orange',
    nodes: [
      { title: 'Secrets', subtitle: 'Linux creds • shadow • SSH keys • env files' },
      { title: 'Memory Dumps', subtitle: 'Mimikatz • LSASS • minidump • DCSync' },
      { title: 'Kerberos & AD', subtitle: 'Kerberoasting • ASREProast • ticket extraction' },
      { title: 'Offline Cracking', subtitle: 'Hashcat • john • wordlists • rules' },
    ]
  },
  {
    header: 'LATERAL MOVEMENT',
    color: 'pink',
    nodes: [
      { title: 'Authentication', subtitle: 'Pass-the-Hash • Overpass-the-Hash • SSH • macOS ARD' },
      { title: 'Remote Execution', subtitle: 'WinRM • PsExec • WMI • DCOM' },
      { title: 'Network Pivoting', subtitle: 'SOCKS • Ligolo-ng • Chisel • SMB relay' },
    ]
  },
  {
    header: 'ACTIVE DIRECTORY',
    color: 'cyan',
    nodes: [
      { title: 'Kerberos Attacks', subtitle: 'Kerberoasting • ASREPRoast • delegation abuse' },
      { title: 'Cert & Policy (ADCS)', subtitle: 'ESC1-13 • Group Policy • credentials in GPO' },
      { title: 'Services & Infra', subtitle: 'MSSQL • SCCM • LAPS • LDAP' },
      { title: 'Trusts & Coercion', subtitle: 'Domain trusts • Printer bug • Coercion' },
      { title: 'Global Schema', subtitle: 'Schema Admin • attribute injection • persistence' },
    ]
  },
  {
    header: 'DOMAIN DOMINANCE',
    color: 'green',
    nodes: [
      { title: 'Ticket Forgery', subtitle: 'Silver • Golden • Diamond tickets' },
      { title: 'Cert & Data', subtitle: 'Cert forgery • Data exfiltration • hunting' },
    ]
  },

  {
    header: 'DEFENSE EVASION',
    color: 'orange',
    nodes: [
      { title: 'Payload & Staging', subtitle: 'Artifact Kit • AMSI bypass • AppLocker' },
      { title: 'C2 Profile & Templates', subtitle: 'Malleable C2 • CLM bypass • Resource Kit' },
      { title: 'Post-Exploitation', subtitle: 'Memory cleanup • RW→RX • Fork-and-run' },
      { title: 'Process Masking', subtitle: 'PPID spoof • Cmd spoof • Pipes • ETW bypass' },
    ]
  },
];


const crtlColumns = [
  {
    header: 'WINDOWS APIS',
    color: 'red',
    nodes: [
      { title: 'Direct API Calls', subtitle: 'CreateProcess • WinAPI • NT APIs' },
      { title: 'Dynamic Invocation', subtitle: 'P/Invoke • D/Invoke • API hashing' },
      { title: 'Error Handling', subtitle: 'GetLastError • NTSTATUS • exceptions' },
    ]
  },
  {
    header: 'PROCESS INJECTION',
    color: 'orange',
    nodes: [
      { title: 'Local Injection', subtitle: 'CreateThread • QueueUserAPC • fiber' },
      { title: 'Remote Injection', subtitle: 'CreateRemoteThread • VirtualAllocEx • APC' },
      { title: 'NT Injection', subtitle: 'NtMapViewOfSection • Section mapping • syscalls' },
    ]
  },
  {
    header: 'MALWARE',
    color: 'red',
    nodes: [
      { title: 'Injection Primitives', subtitle: 'Process injection • reflective DLL • hollowing' },
      { title: 'API & Syscalls', subtitle: 'API hashing • IAT hiding • direct & indirect syscalls' },
      { title: 'Evasion', subtitle: 'AMSI • ETW • anti-debug • sandbox detect • entropy' },
      { title: 'Loader & Staging', subtitle: 'Loader dev • payload staging • sleep masking • packer' },
      { title: 'Stealth', subtitle: 'PPID spoof • arg spoof • NTDLL unhook • DLL sideload • keylogger' },
      { title: 'Build & Sign', subtitle: 'MinGW cross-compile • Authenticode • HWBP evasion' },
    ]
  },
  {
    header: 'ASR & WDAC',
    color: 'yellow',
    nodes: [
      { title: 'ASR', subtitle: 'Rule enumeration • exclusion abuse • bypass' },
      { title: 'WDAC', subtitle: 'Policy enum • LOLBAS • trusted signers • filename rules' },
    ]
  },
  {
    header: 'EDR EVASION',
    color: 'cyan',
    nodes: [
      { title: 'Hook & Syscall', subtitle: 'Hook detection • direct & indirect syscalls' },
      { title: 'Implant Evasion', subtitle: 'Sleep mask • stack spoof • UDRL' },
      { title: 'Kernel Level', subtitle: 'Kernel callbacks • BYOVD • DKOM' },
      { title: 'Vendor Specific', subtitle: 'CrowdStrike • MDE • SentinelOne • Cortex • Elastic • ESET' },
    ]
  },

  {
    header: 'DEVOPS',
    color: 'blue',
    nodes: [
      { title: 'Docker & K8s', subtitle: 'Container escape • RBAC • service accounts' },
      { title: 'CI/CD Pipelines', subtitle: 'Jenkins • GitHub Actions • GitLab CI' },
      { title: 'Config Management', subtitle: 'Ansible • Terraform • vault decrypt' },
      { title: 'Secrets Management', subtitle: 'HashiCorp Vault • AWS SSM • IMDS' },
    ]
  },
  {
    header: 'AI / ML',
    color: 'purple',
    nodes: [
      { title: 'Prompt Injection', subtitle: 'Direct • indirect • jailbreak • system leak' },
      { title: 'LLM Output Attacks', subtitle: 'Markdown inject • exfil • downstream' },
      { title: 'AI Data Attacks', subtitle: 'Training poison • backdoor • RAG poison' },
      { title: 'App & System', subtitle: 'Plugin abuse • agent hijack • supply chain' },
      { title: 'AI Evasion', subtitle: 'FGSM • PGD • one-pixel • patch attacks' },
      { title: 'AI Privacy', subtitle: 'Membership inference • model inversion • extraction' },
    ]
  },
];

const allColumns = [...crtoColumns, ...crtlColumns];

const crtoLegend = [
  { label: 'C2 & OPSEC', color: 'bg-cyan-400' },
  { label: 'Reconnaissance', color: 'bg-cyan-400' },
  { label: 'Initial Compromise', color: 'bg-emerald-400' },
  { label: 'Host Operations', color: 'bg-emerald-400' },
  { label: 'Privilege Escalation', color: 'bg-red-400' },
  { label: 'Credential Access', color: 'bg-red-400' },
  { label: 'Lateral Movement', color: 'bg-orange-400' },
  { label: 'Active Directory', color: 'bg-pink-400' },
  { label: 'Domain Dominance', color: 'bg-yellow-400' },
  { label: 'Evasion', color: 'bg-orange-400' },
];



const colorOptions = [
  { name: 'Cyan', value: 'cyan' },
  { name: 'Green', value: 'green' },
  { name: 'Red', value: 'red' },
  { name: 'Purple', value: 'purple' },
  { name: 'Orange', value: 'orange' },
  { name: 'Pink', value: 'pink' },
  { name: 'Blue', value: 'blue' },
  { name: 'Yellow', value: 'yellow' },
];

const colorPreview = {
  cyan: 'bg-cyan-400',
  green: 'bg-emerald-400',
  red: 'bg-red-400',
  purple: 'bg-purple-400',
  orange: 'bg-orange-400',
  pink: 'bg-pink-400',
  blue: 'bg-blue-400',
  yellow: 'bg-yellow-400',
};

const headerColorMap = {
  cyan: 'text-cyan-400 border-cyan-500/30',
  green: 'text-emerald-400 border-emerald-500/30',
  red: 'text-red-400 border-red-500/30',
  purple: 'text-purple-400 border-purple-500/30',
  orange: 'text-orange-400 border-orange-500/30',
  pink: 'text-pink-400 border-pink-500/30',
  blue: 'text-blue-400 border-blue-500/30',
  yellow: 'text-yellow-400 border-yellow-500/30',
};

export default function Home() {
  const [columns, setColumns] = useState(allColumns);
  const [modalStep, setModalStep] = useState(null); // null, 'name', 'color'
  const [columnName, setColumnName] = useState('');
  const [selectedColor, setSelectedColor] = useState('cyan');
  const [addingTopicCol, setAddingTopicCol] = useState(null);
  const [topicTitle, setTopicTitle] = useState('');
  const [topicTags, setTopicTags] = useState('');
  const [customCards, setCustomCards] = useState([]);
  const [cardModalOpen, setCardModalOpen] = useState(false);

  const handleAddColumnStart = () => {
    setColumnName('');
    setModalStep('name');
  };

  const handleNameSubmit = () => {
    if (columnName.trim()) {
      setModalStep('color');
    }
  };

  const handleColorSubmit = () => {
    const newColumn = {
      header: columnName.toUpperCase(),
      color: selectedColor,
      nodes: [
        { title: 'Topic 1', subtitle: 'Add your content here' },
      ]
    };
    setColumns([...columns, newColumn]);
    setModalStep(null);
    setSelectedColor('cyan');
    setColumnName('');
  };

  const handleDeleteColumn = (index) => {
    setColumns(columns.filter((_, i) => i !== index));
  };

  const handleAddTopic = (colIndex) => {
    if (topicTitle.trim()) {
      const updatedColumns = [...columns];
      updatedColumns[colIndex].nodes.push({
        title: topicTitle,
        subtitle: 'Add details here',
        tags: topicTags.split(',').map(tag => tag.trim()).filter(tag => tag)
      });
      setColumns(updatedColumns);
      setAddingTopicCol(null);
      setTopicTitle('');
      setTopicTags('');
    }
  };

  const handleDeleteTopic = (colIndex, nodeIndex) => {
    const updatedColumns = [...columns];
    updatedColumns[colIndex].nodes.splice(nodeIndex, 1);
    setColumns(updatedColumns);
  };

  const handleAddCard = (cardData) => {
    setCustomCards([...customCards, cardData]);
  };

  const handleDeleteCard = (cardId) => {
    setCustomCards(customCards.filter(c => c.id !== cardId));
  };

  return (
    <div>
      {/* Title */}
      <div className="text-center mb-10">
        <h1 className="text-3xl md:text-5xl font-bold font-mono tracking-tight">
          <span className="text-red-500">Red Team</span>
          <span className="text-slate-200"> Operations</span>
        </h1>
        <p className="text-slate-500 font-mono text-sm mt-3">
          Full Red Team Operations Reference — Methodology, Tooling &amp; Techniques
        </p>
      </div>

      {/* Description */}
      <div className="max-w-3xl mx-auto text-center mb-10">
        <p className="text-slate-400 text-sm leading-relaxed">
          A personal red team operations reference covering the full adversary lifecycle — from initial reconnaissance and compromise through to domain dominance and EDR evasion. Built as a cheatsheet for offensive security engagements, certification prep, and tool research.
        </p>
      </div>

      {/* Creator */}
      <div className="max-w-sm mx-auto mb-12 bg-[#0d1117] border border-slate-800/50 rounded-xl p-5 flex items-center gap-4">
        <div className="w-10 h-10 rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center flex-shrink-0">
          <span className="text-red-400 font-mono font-bold text-sm">WX</span>
        </div>
        <div>
          <p className="text-slate-200 font-mono font-semibold text-sm">Wencheng Xue</p>
          <p className="text-slate-500 font-mono text-xs mt-0.5">University of Cincinnati · Cybersecurity</p>
          <span className="inline-block mt-1.5 text-[10px] font-mono px-2 py-0.5 rounded-full bg-red-500/10 text-red-400 border border-red-500/20">OSCE3</span>
        </div>
      </div>

      {/* Combined Map */}
      <div className="overflow-x-auto pb-4">
        <div className="inline-flex gap-4 min-w-max">
          {columns.map((col, i) => {
            const color = col.color || 'cyan';
            const hColors = headerColorMap[color];
            return (
              <div key={i} className="flex flex-col gap-2 min-w-[180px] max-w-[200px] relative">
                <div className={`text-center py-2 border-b-2 mb-2 ${hColors} flex items-center justify-between px-2`}>
                  <span className="font-mono text-[11px] font-bold tracking-[0.2em] uppercase flex-1">
                    {col.header}
                  </span>
                  <button
                    onClick={() => handleDeleteColumn(i)}
                    className="text-slate-500 hover:text-slate-300 transition-colors p-0.5"
                    title="Delete column"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
                <div className="flex flex-col gap-2 border border-slate-800/50 rounded-lg p-2 bg-[#0d1117]">
                  {col.nodes.map((node, j) => (
                    <div key={j} className="flex items-start gap-1 group">
                      <div className="flex-1 min-w-0">
                        <MapNode
                          title={node.title}
                          subtitle={node.tags && node.tags.length > 0 ? node.tags.join(' • ') : node.subtitle}
                          accentColor={color}
                          small
                        />
                      </div>
                      <button
                        onClick={() => handleDeleteTopic(i, j)}
                        className="text-slate-600 hover:text-red-400 transition-colors p-0.5 flex-shrink-0 opacity-0 group-hover:opacity-100"
                        title="Delete topic"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                  
                  {addingTopicCol === i ? (
                    <div className="flex flex-col gap-1">
                      <input
                        type="text"
                        value={topicTitle}
                        onChange={(e) => setTopicTitle(e.target.value)}
                        placeholder="Topic name"
                        className="px-2 py-1 bg-slate-800 border border-slate-700 rounded text-slate-200 placeholder-slate-500 font-mono text-xs focus:outline-none focus:border-slate-500"
                        autoFocus
                        onKeyDown={(e) => {
                          if (e.key === 'Escape') {
                            setAddingTopicCol(null);
                            setTopicTitle('');
                            setTopicTags('');
                          }
                        }}
                      />
                      <input
                        type="text"
                        value={topicTags}
                        onChange={(e) => setTopicTags(e.target.value)}
                        placeholder="Tags (comma-separated)"
                        className="px-2 py-1 bg-slate-800 border border-slate-700 rounded text-slate-200 placeholder-slate-500 font-mono text-xs focus:outline-none focus:border-slate-500"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleAddTopic(i);
                          if (e.key === 'Escape') {
                            setAddingTopicCol(null);
                            setTopicTitle('');
                            setTopicTags('');
                          }
                        }}
                      />
                      <div className="flex gap-1">
                        <button
                          onClick={() => handleAddTopic(i)}
                          className="flex-1 px-2 py-1 bg-cyan-600 hover:bg-cyan-700 text-white text-xs font-mono rounded transition-colors"
                        >
                          Add
                        </button>
                        <button
                          onClick={() => {
                            setAddingTopicCol(null);
                            setTopicTitle('');
                            setTopicTags('');
                          }}
                          className="flex-1 px-2 py-1 bg-slate-700 hover:bg-slate-600 text-slate-300 text-xs font-mono rounded transition-colors"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button
                      onClick={() => setAddingTopicCol(i)}
                      className="px-2 py-1 text-xs font-mono text-slate-500 hover:text-slate-300 border border-dashed border-slate-700 rounded hover:border-slate-500 transition-colors"
                    >
                      + Add Topic
                    </button>
                  )}
                </div>
              </div>
            );
          })}
          
          {/* Add Column Button */}
          <div className="flex flex-col gap-2 min-w-[180px] max-w-[200px]">
            <button
              onClick={handleAddColumnStart}
              className="h-full flex flex-col items-center justify-center gap-2 border-2 border-dashed border-slate-700 rounded-lg p-4 hover:border-slate-500 hover:bg-slate-800/20 transition-all"
            >
              <Plus className="w-6 h-6 text-slate-500" />
              <span className="text-xs font-mono text-slate-500 text-center">Add Column</span>
            </button>
          </div>
        </div>
      </div>

      {/* Modal for Adding Column */}
      {modalStep && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-[#0d1117] border border-slate-800 rounded-lg p-6 max-w-sm w-full mx-4">
            {modalStep === 'name' && (
              <div className="space-y-4">
                <h3 className="text-lg font-mono font-bold text-slate-200">Column Name</h3>
                <input
                  type="text"
                  value={columnName}
                  onChange={(e) => setColumnName(e.target.value)}
                  placeholder="e.g., Custom Category"
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-200 placeholder-slate-500 font-mono text-sm focus:outline-none focus:border-slate-500"
                  autoFocus
                  onKeyDown={(e) => e.key === 'Enter' && handleNameSubmit()}
                />
                <div className="flex gap-2">
                  <button
                    onClick={() => setModalStep(null)}
                    className="flex-1 px-4 py-2 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700 transition-colors font-mono text-sm"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleNameSubmit}
                    className="flex-1 px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700 transition-colors font-mono text-sm font-semibold"
                  >
                    Next
                  </button>
                </div>
              </div>
            )}

            {modalStep === 'color' && (
              <div className="space-y-4">
                <h3 className="text-lg font-mono font-bold text-slate-200">Choose Color</h3>
                <div className="flex flex-col gap-2 max-h-64 overflow-y-auto">
                  {colorOptions.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => setSelectedColor(option.value)}
                      className={`px-4 py-2 rounded-lg text-sm font-mono font-semibold transition-all flex items-center gap-2 ${
                        selectedColor === option.value
                          ? `${colorPreview[option.value]} text-slate-900`
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      <div className={`w-3 h-3 rounded-full ${colorPreview[option.value]}`} />
                      {option.name}
                    </button>
                  ))}
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setModalStep('name')}
                    className="flex-1 px-4 py-2 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700 transition-colors font-mono text-sm"
                  >
                    Back
                  </button>
                  <button
                    onClick={handleColorSubmit}
                    className="flex-1 px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700 transition-colors font-mono text-sm font-semibold"
                  >
                    Create
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Custom Cards Section */}
      {customCards.length > 0 && (
        <div className="border-t border-slate-800/50 pt-12 mt-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold font-mono text-slate-200">Custom Techniques</h2>
            <button
              onClick={() => setCardModalOpen(true)}
              className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-700 text-white text-xs font-mono rounded transition-colors flex items-center gap-1"
            >
              <Plus className="w-3 h-3" /> Add Technique
            </button>
          </div>
          <div className="grid grid-cols-1 gap-4">
            {customCards.map((card) => (
              <div key={card.id} className="relative">
                <TechniqueCard
                  title={card.title}
                  subtitle={card.subtitle}
                  tags={card.tags}
                  accentColor={card.accentColor}
                  overview={card.overview}
                  steps={card.steps}
                  commands={card.commands}
                />
                <button
                  onClick={() => handleDeleteCard(card.id)}
                  className="absolute top-4 right-4 text-slate-600 hover:text-red-400 transition-colors p-1 z-10"
                  title="Delete card"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add Card Button (when no custom cards) */}
      {customCards.length === 0 && (
        <div className="border-t border-slate-800/50 pt-12 mt-12">
          <button
            onClick={() => setCardModalOpen(true)}
            className="w-full py-6 border-2 border-dashed border-slate-700 rounded-lg hover:border-slate-500 hover:bg-slate-800/20 transition-all flex flex-col items-center justify-center gap-2"
          >
            <Plus className="w-6 h-6 text-slate-500" />
            <span className="text-sm font-mono text-slate-500">Add Technique Card</span>
          </button>
        </div>
      )}

      <AddCardModal
        isOpen={cardModalOpen}
        onClose={() => setCardModalOpen(false)}
        onSubmit={handleAddCard}
      />
    </div>
  );
}