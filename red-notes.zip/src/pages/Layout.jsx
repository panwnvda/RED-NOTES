import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Shield, ChevronRight, Plus, Trash2 } from 'lucide-react';

function loadCustomPages() {
  try {
    const s = localStorage.getItem('redops_custom_pages');
    return s ? JSON.parse(s) : [];
  } catch { return []; }
}

function saveCustomPages(pages) {
  try { localStorage.setItem('redops_custom_pages', JSON.stringify(pages)); } catch {}
}

function loadHiddenPages() {
  try {
    const s = localStorage.getItem('redops_hidden_pages');
    return s ? JSON.parse(s) : [];
  } catch { return []; }
}

function saveHiddenPages(pages) {
  try { localStorage.setItem('redops_hidden_pages', JSON.stringify(pages)); } catch {}
}

const crtoItems = [
  { name: 'OPSEC', page: 'C2OPSEC', color: 'text-cyan-400' },
  { name: 'Reconnaissance', page: 'Reconnaissance', color: 'text-cyan-400' },
  { name: 'Initial Compromise', page: 'InitialCompromise', color: 'text-emerald-400' },
  { name: 'Wi-Fi', page: 'WiFi', color: 'text-cyan-400' },
  { name: 'Web Applications', page: 'WebApplications', color: 'text-blue-400' },
  { name: 'Execution', page: 'Execution', color: 'text-emerald-400' },
  { name: 'Host Operations', page: 'HostOperations', color: 'text-emerald-400' },
  { name: 'Privilege Escalation', page: 'PrivilegeEscalation', color: 'text-red-400' },
  { name: 'Credential Access', page: 'CredentialAccess', color: 'text-red-400' },
  { name: 'Lateral Movement', page: 'LateralMovement', color: 'text-orange-400' },
  { name: 'Active Directory', page: 'ADAttacks', color: 'text-pink-400' },
  { name: 'Domain Dominance', page: 'DomainDominance', color: 'text-yellow-400' },
  { name: 'Defense Evasion', page: 'EvasionCRTO', color: 'text-orange-400' },
];

const levelItems = [
  { name: 'WinAPIs', page: 'WindowsAPIs', color: 'text-emerald-400' },
  { name: 'Process Injection', page: 'ProcessInjection', color: 'text-red-400' },
  { name: 'Malware', page: 'Malware', color: 'text-red-400' },
  { name: 'ASR & WDAC', page: 'ASRAndWDAC', color: 'text-orange-400' },
  { name: 'EDR Evasion', page: 'EDREvasion', color: 'text-red-400' },
  { name: 'DevOps', page: 'DevOps', color: 'text-blue-400' },
  { name: 'AI / ML', page: 'AIML', color: 'text-purple-400' },
  { name: 'Tools', page: 'Tools', color: 'text-yellow-400' },
];

const navItems = [
  { name: 'Home', page: 'Home', color: 'text-slate-300' },
  ...crtoItems,
  ...levelItems,
];

// Context menu component
function NavContextMenu({ x, y, label, onDelete, onClose }) {
  const ref = useRef(null);

  useEffect(() => {
    const handle = (e) => {
      if (ref.current && !ref.current.contains(e.target)) onClose();
    };
    document.addEventListener('mousedown', handle);
    return () => document.removeEventListener('mousedown', handle);
  }, [onClose]);

  return (
    <div
      ref={ref}
      className="fixed z-[200] bg-[#0d1117] border border-slate-700 rounded-lg shadow-xl py-1 min-w-[160px]"
      style={{ top: y, left: x }}
    >
      <div className="px-3 py-1.5 text-[11px] font-mono text-slate-500 border-b border-slate-800 mb-1">{label}</div>
      <button
        onClick={onDelete}
        className="w-full text-left px-3 py-2 text-sm font-mono text-red-400 hover:bg-red-500/10 transition-colors flex items-center gap-2"
      >
        <Trash2 className="w-3.5 h-3.5" /> Delete Page
      </button>
    </div>
  );
}

export default function Layout({ children, currentPageName }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [customPages, setCustomPages] = useState(() => loadCustomPages());
  const [addPageOpen, setAddPageOpen] = useState(false);
  const [newPageName, setNewPageName] = useState('');
  const [newPageType, setNewPageType] = useState('notes');
  const [contextMenu, setContextMenu] = useState(null); // { x, y, label, pageKey?, builtinPage? }
  const [hiddenPages, setHiddenPages] = useState(() => loadHiddenPages());

  const pageTypes = [
    { value: 'notes', label: 'Notes', desc: 'Map + technique cards' },
    { value: 'resource', label: 'Resources', desc: 'Categorized links' },
    { value: 'text', label: 'Text', desc: 'Free-form text sections' },
    { value: 'home', label: 'Home', desc: 'Full methodology dashboard' },
  ];

  const handleAddPage = () => {
    const name = newPageName.trim();
    if (!name) return;
    const key = 'custom_' + name.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '') + '_' + Date.now();
    try { localStorage.setItem(`redops_pagetype_${key}`, newPageType); } catch {}
    const page = { name, key };
    const updated = [...customPages, page];
    setCustomPages(updated);
    saveCustomPages(updated);
    setNewPageName('');
    setNewPageType('notes');
    setAddPageOpen(false);
    window.location.href = `/custom/${key}`;
  };

  const handleDeletePage = (key) => {
    const updated = customPages.filter(p => p.key !== key);
    setCustomPages(updated);
    saveCustomPages(updated);
    setContextMenu(null);
    if (currentPageName === `custom/${key}`) window.location.href = '/';
  };

  const handleHideBuiltinPage = (page) => {
    const updated = [...hiddenPages, page];
    setHiddenPages(updated);
    saveHiddenPages(updated);
    setContextMenu(null);
    if (currentPageName === page) window.location.href = '/';
  };

  const openContextMenu = (e, label, pageKey = null, builtinPage = null) => {
    e.preventDefault();
    // Keep menu inside viewport
    const x = Math.min(e.clientX, window.innerWidth - 180);
    const y = Math.min(e.clientY, window.innerHeight - 100);
    setContextMenu({ x, y, label, pageKey, builtinPage });
  };

  return (
    <div className="min-h-screen bg-[#0a0e1a]">
      {/* Top Nav */}
      <nav className="sticky top-0 z-50 bg-[#0a0e1a]/90 backdrop-blur-xl border-b border-slate-800/50">
        <div className="max-w-[1440px] mx-auto px-4 md:px-6">
          <div className="flex items-center justify-between h-14">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2.5 group mr-8">
              <Shield className="w-5 h-5 text-red-500 group-hover:text-red-400 transition-colors" />
              <span className="font-mono font-bold text-sm text-white hidden sm:block">
                RED <span className="text-red-500">|</span> NOTES
              </span>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-1 overflow-x-auto flex-1 px-4" style={{ scrollbarWidth: 'thin' }}>
              {navItems.filter(item => !hiddenPages.includes(item.page)).map((item) => (
                <Link
                  key={item.page}
                  to={`/${item.page}`}
                  onContextMenu={(e) => openContextMenu(e, item.name, null, item.page)}
                  className={`px-3 py-1.5 rounded-md text-xs font-mono font-medium transition-all whitespace-nowrap ${
                    currentPageName === item.page
                      ? `${item.color} bg-white/5`
                      : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
                  }`}
                >
                  {item.name}
                </Link>
              ))}
              {customPages.map((p) => (
                <Link
                  key={p.key}
                  to={`/custom/${p.key}`}
                  onContextMenu={(e) => openContextMenu(e, p.name, p.key)}
                  className={`px-3 py-1.5 rounded-md text-xs font-mono font-medium transition-all whitespace-nowrap ${
                    currentPageName === `custom/${p.key}`
                      ? 'text-slate-300 bg-white/5'
                      : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
                  }`}
                >
                  {p.name}
                </Link>
              ))}
              {/* Add Page button */}
              <button
                onClick={() => setAddPageOpen(true)}
                className="ml-2 flex-shrink-0 px-2.5 py-1.5 rounded-md text-xs font-mono font-medium text-slate-600 hover:text-slate-300 hover:bg-white/5 transition-all flex items-center gap-1 border border-dashed border-slate-700 hover:border-slate-500"
              >
                <Plus className="w-3 h-3" /> New Page
              </button>
            </div>

            {/* Mobile Toggle */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden text-slate-400 hover:text-slate-200 transition-colors"
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Nav */}
        {mobileOpen && (
          <div className="md:hidden border-t border-slate-800/50 bg-[#0a0e1a]/95 backdrop-blur-xl">
            <div className="px-4 py-3 space-y-1">
              {navItems.filter(item => !hiddenPages.includes(item.page)).map((item) => (
                <Link
                  key={item.page}
                  to={`/${item.page}`}
                  onClick={() => setMobileOpen(false)}
                  onContextMenu={(e) => openContextMenu(e, item.name, null, item.page)}
                  className={`flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-mono transition-all ${
                    currentPageName === item.page
                      ? `${item.color} bg-white/5`
                      : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
                  }`}
                >
                  <ChevronRight className="w-3 h-3" />
                  {item.name}
                </Link>
              ))}
              {customPages.map((p) => (
                <Link
                  key={p.key}
                  to={`/custom/${p.key}`}
                  onClick={() => setMobileOpen(false)}
                  onContextMenu={(e) => openContextMenu(e, p.name, p.key)}
                  className={`flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-mono transition-all ${
                    currentPageName === `custom/${p.key}`
                      ? 'text-slate-300 bg-white/5'
                      : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
                  }`}
                >
                  <ChevronRight className="w-3 h-3" />
                  {p.name}
                </Link>
              ))}
              <button
                onClick={() => { setMobileOpen(false); setAddPageOpen(true); }}
                className="flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-mono text-slate-500 hover:text-slate-300 hover:bg-white/5 transition-all w-full border border-dashed border-slate-700"
              >
                <Plus className="w-3 h-3" /> New Page
              </button>
            </div>
          </div>
        )}
      </nav>

      {/* Context Menu */}
      {contextMenu && (
        <NavContextMenu
          x={contextMenu.x}
          y={contextMenu.y}
          label={contextMenu.label}
          onDelete={() => contextMenu.pageKey ? handleDeletePage(contextMenu.pageKey) : handleHideBuiltinPage(contextMenu.builtinPage)}
          onClose={() => setContextMenu(null)}
        />
      )}

      {/* Add Page Modal */}
      {addPageOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[100]">
          <div className="bg-[#0d1117] border border-slate-800 rounded-lg p-6 max-w-sm w-full mx-4 space-y-4">
            <h3 className="text-lg font-mono font-bold text-slate-200">New Page</h3>
            <div>
              <label className="block text-xs font-mono text-slate-500 mb-1">PAGE NAME</label>
              <input
                type="text"
                value={newPageName}
                onChange={e => setNewPageName(e.target.value)}
                placeholder="e.g., Cloud Attacks"
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-200 placeholder-slate-500 font-mono text-sm focus:outline-none focus:border-slate-500"
                autoFocus
                onKeyDown={e => { if (e.key === 'Enter') handleAddPage(); if (e.key === 'Escape') setAddPageOpen(false); }}
              />
            </div>
            <div>
              <label className="block text-xs font-mono text-slate-500 mb-2">PAGE TYPE</label>
              <div className="space-y-2">
                {pageTypes.map(pt => (
                  <button key={pt.value} onClick={() => setNewPageType(pt.value)}
                    className={`w-full text-left px-3 py-2.5 rounded-lg border transition-all font-mono ${newPageType === pt.value ? 'border-cyan-500/50 bg-cyan-500/10 text-slate-200' : 'border-slate-700 bg-slate-800 text-slate-400 hover:border-slate-500'}`}>
                    <div className="text-sm font-semibold">{pt.label}</div>
                    <div className="text-xs text-slate-500 mt-0.5">{pt.desc}</div>
                  </button>
                ))}
              </div>
            </div>
            <div className="flex gap-2">
              <button onClick={() => { setAddPageOpen(false); setNewPageName(''); setNewPageType('notes'); }} className="flex-1 px-4 py-2 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700 transition-colors font-mono text-sm">Cancel</button>
              <button onClick={handleAddPage} disabled={!newPageName.trim()} className="flex-1 px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-mono text-sm font-semibold">Create</button>
            </div>
          </div>
        </div>
      )}

      {/* Content */}
      <main className="max-w-[1440px] mx-auto px-4 md:px-6 py-8 md:py-12">
        {children}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/50 py-6">
        <div className="max-w-[1440px] mx-auto px-4 md:px-6">
          <p className="text-center text-slate-600 font-mono text-xs">
            Red Team Operations Reference
          </p>
        </div>
      </footer>
    </div>
  );
}