# Red Manual

This project is a standard Vite + React app.

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Notes

- The `@` import alias resolves to `src/`.
- Authentication is handled locally in the app.

## Local development

Run:

```bash
npm install
npm run dev
```

Then open the local URL Vite prints in the terminal, usually `http://127.0.0.1:5173/` or `http://localhost:5173/`.

Note: the previous config suppressed Vite startup output, which could make `npm run dev` look like it was hanging even when the dev server was actually running.
