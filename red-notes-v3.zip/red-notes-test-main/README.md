# Red Notes

Red Notes is now a local-first Vite app.

## How it works

All data is stored in the browser with `localStorage`.
The app no longer depends on any external backend integration for auth, storage, or page generation.

## Run locally

1. Install dependencies:
   `npm install`
2. Start the dev server:
   `npm run dev`

## Notes

- Authentication is disabled.
- Persistent storage is browser-local.
- The page-generation helper now uses a local template generator instead of a remote service.
