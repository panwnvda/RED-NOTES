import React from 'react';
import HomePage from './custom/HomePage';

const HOME_KEY = 'rtHome';

function seedIfEmpty() {
  const metaKey = `redops_homemeta_${HOME_KEY}`;
  const colKey = `redops_columns_${HOME_KEY}`;
  try {
    if (!localStorage.getItem(metaKey)) {
      localStorage.setItem(metaKey, JSON.stringify({
        titleLeft: 'Red Team',
        titleRight: 'Operations',
        titleLeftColor: 'red',
        description: 'Full Red Team Operations Reference — Methodology, Tooling & Techniques',
        authorInitials: 'WX',
        authorName: 'Wencheng Xue',
        authorSub: 'University of Cincinnati · Cybersecurity',
        authorTag: 'CRTO',
      }));
    }
    if (!localStorage.getItem(colKey)) {
      localStorage.setItem(colKey, JSON.stringify([
        {
          header: 'OPSEC',
          color: 'cyan',
          nodes: [
            { title: 'C2', subtitle: 'Cobalt Strike · Sliver · Listeners · proxies', tags: [], id: 'h-c2' },
            { title: 'Infrastructure', subtitle: 'Port scanning · FTP · SSH · DNS · channels', tags: [], id: 'h-infra' },
            { title: 'Payloads', subtitle: 'BOFs · Shellcode Runners · OPSEC principles', tags: [], id: 'h-pay' },
          ]
        },
        {
          header: 'RECONNAISSANCE',
          color: 'cyan',
          nodes: [
            { title: 'OSINT', subtitle: 'Link helpers · DNS Records · Google Dorks · Social Media', tags: [], id: 'h-osint' },
            { title: 'Scanning', subtitle: 'Port scanning · FTP · SSH · SMB · SMTP · IIS', tags: [], id: 'h-scan' },
            { title: 'Packet Capture', subtitle: 'Wireshark · tcpdump · NetFlow', tags: [], id: 'h-pkt' },
            { title: 'Internal Recon', subtitle: 'Domain Recon · Credential · PowerView · ADSearch', tags: [], id: 'h-intr' },
          ]
        },
        {
          header: 'INITIAL COMPROMISE',
          color: 'green',
          nodes: [
            { title: 'Credential Attacks', subtitle: 'Password Spraying · Kerberoasting · ADCS', tags: [], id: 'h-cred' },
            { title: 'Phishing', subtitle: 'AiTM · Evilginx · GoPhish · teamphisher.py · droppers', tags: [], id: 'h-phish' },
            { title: 'Payload Development', subtitle: 'Shellcode Development · Loaders', tags: [], id: 'h-pdev' },
            { title: 'Delivery', subtitle: 'VBA Macros · ISO · HTML Smuggling · Supply Chain · AIA', tags: [], id: 'h-del' },
            { title: 'Physical & USB', subtitle: 'Rubber Ducky & HID · Malicious USB Drops', tags: [], id: 'h-phys' },
          ]
        },
        {
          header: 'WI-FI',
          color: 'blue',
          nodes: [
            { title: 'Wi-Fi Reconnaissance', subtitle: 'Monitoring · Signal · Heatmapping · Clients', tags: [], id: 'h-wfr' },
            { title: 'WPA2 Attacks', subtitle: 'Handshake · PMKID · Offline cracking', tags: [], id: 'h-wpa2' },
            { title: 'WPA3 Attacks', subtitle: 'Pixie Dust · PM Brute-force · Dragonblood', tags: [], id: 'h-wpa3' },
            { title: 'Evil Twin', subtitle: 'Evil twin · Captive portal · Deauth', tags: [], id: 'h-wpa3b' },
            { title: 'WPA Enterprise (802.1X)', subtitle: 'Windows EAP · RADIUS · admin', tags: [], id: 'h-ent' },
          ]
        },
        {
          header: 'WEB APPLICATIONS',
          color: 'purple',
          nodes: [
            { title: 'Web Reconnaissance', subtitle: 'Subdomain enum · Fingerprinting · mapping', tags: [], id: 'h-webr' },
            { title: 'Authentication', subtitle: 'Brute force · JWT · MFA · SSO abuses', tags: [], id: 'h-auth' },
            { title: 'Session Management', subtitle: 'Session Fixation · CSRF · cookies', tags: [], id: 'h-sess' },
            { title: 'Authorization', subtitle: 'IDOR · BOLA · Privilege Escalation · Isolation', tags: [], id: 'h-authz' },
            { title: 'Server-Side Attacks', subtitle: 'SQLi · RCE · SSRF · XXE · SSTI', tags: [], id: 'h-ssa' },
            { title: 'Client-Side Attacks', subtitle: 'XSS · DOM · CSRF · XSLeaks', tags: [], id: 'h-csa' },
          ]
        },
        {
          header: 'EXECUTION',
          color: 'red',
          nodes: [
            { title: 'Shellcode & DLL', subtitle: 'Injection · Reflective · Base · loader plugins', tags: [], id: 'h-sh' },
            { title: 'Managed Code', subtitle: 'Assembly loading · .NET · PowerShell', tags: [], id: 'h-mc' },
            { title: 'LOLBINs & Scripts', subtitle: 'Living off the land · systems · BAD · Lolengine', tags: [], id: 'h-lol' },
            { title: 'Remote & Token', subtitle: 'WMI · DCOM · Token Impersonation', tags: [], id: 'h-rt' },
          ]
        },
        {
          header: 'HOST OPS',
          color: 'orange',
          nodes: [
            { title: 'Host Recon', subtitle: 'sysinfo · ps · net · whoami · ipconfig', tags: [], id: 'h-hr' },
            { title: 'User Persistence', subtitle: 'Startup · Task Scheduler · registry', tags: [], id: 'h-up' },
            { title: 'Elevated Persistence', subtitle: 'Services · WMI · Linux systemd · macOS LaunchAgents', tags: [], id: 'h-ep' },
          ]
        },
        {
          header: 'PRIVILEGE ESCALATION',
          color: 'red',
          nodes: [
            { title: 'Service Exploits', subtitle: 'Weak perms · binary perms · unquoted · TCC/SIP bypass', tags: [], id: 'h-se' },
            { title: 'Token & Secrets', subtitle: 'Token impersonation · DPAPI · SUID · sudo', tags: [], id: 'h-ts' },
            { title: 'Kernel Exploits', subtitle: 'DirtyPipe · PwnKit · PrintNightmare · EternalBlue', tags: [], id: 'h-ke' },
          ]
        },
        {
          header: 'CREDENTIAL ACCESS',
          color: 'orange',
          nodes: [
            { title: 'Secrets', subtitle: 'Linux creds · shadow · SSH keys · env Files', tags: [], id: 'h-sec' },
            { title: 'Memory Dumps', subtitle: 'Mimikatz · LSASS · minidump · DCSync', tags: [], id: 'h-mem' },
            { title: 'Kerberos & AD', subtitle: 'Kerberoasting · ASREPRoast · ticket extraction', tags: [], id: 'h-kerb' },
            { title: 'Offline Cracking', subtitle: 'Hashcat · john · wordlists · rules', tags: [], id: 'h-crack' },
          ]
        },
        {
          header: 'LATERAL MOVEMENT',
          color: 'pink',
          nodes: [
            { title: 'Authentication', subtitle: 'Pass-the-Hash · Overpass-the-Hash · SSH · macOS ARD', tags: [], id: 'h-lauth' },
            { title: 'Remote Execution', subtitle: 'WinRM · PsExec · WMI · DCOM', tags: [], id: 'h-rex' },
            { title: 'Network Pivoting', subtitle: 'SOCKS · Ligolo-ng · Chisel · SMB relay', tags: [], id: 'h-pivot' },
          ]
        },
        {
          header: 'ACTIVE DIRECTORY',
          color: 'pink',
          nodes: [
            { title: 'Kerberos Attacks', subtitle: 'Kerberoasting · ASREPRoast · delegation abuse', tags: [], id: 'h-kerb2' },
            { title: 'Cert & Policy (ADCS)', subtitle: 'ESC1-13 · Group Policy · credentials in GPO', tags: [], id: 'h-adcs' },
            { title: 'Services & Infra', subtitle: 'MSSQL · SCCM · LAPS · LDAP', tags: [], id: 'h-svc' },
            { title: 'Trusts & Coercion', subtitle: 'Domain trusts · Printer Bug · Coercion', tags: [], id: 'h-trust' },
            { title: 'Global Schema', subtitle: 'Schema Admin · attribute injection · persistence', tags: [], id: 'h-schema' },
          ]
        },
        {
          header: 'DOMAIN DOMINANCE',
          color: 'yellow',
          nodes: [
            { title: 'Ticket Forgery', subtitle: 'Silver · Golden · Diamond tickets', tags: [], id: 'h-ticket' },
            { title: 'Cert & Data', subtitle: 'Cert Forgery · Data exfiltration · hunting', tags: [], id: 'h-cert' },
          ]
        },
        {
          header: 'DEFENSE EVASION',
          color: 'orange',
          nodes: [
            { title: 'Payload & Staging', subtitle: 'Artifact Kit · AMSI Bypass · AppLocker', tags: [], id: 'h-pevade' },
            { title: 'C2 Profile & Templates', subtitle: 'Malleable C2 · CLM bypass · Resource Kit', tags: [], id: 'h-c2prof' },
            { title: 'Post-Exploitation', subtitle: 'Memory cleanup · RawRX · Fork-and-run', tags: [], id: 'h-postex' },
            { title: 'Process Masking', subtitle: 'PPID spoof · Cmd spoof · Pipes · ETW bypass', tags: [], id: 'h-pmask' },
          ]
        },
        {
          header: 'WINDOWS APIs',
          color: 'green',
          nodes: [
            { title: 'Direct API Calls', subtitle: 'CreateProcess · QueueUserAPC · NT APIs', tags: [], id: 'h-dapi' },
            { title: 'Dynamic Invocation', subtitle: 'P/Invoke · D/Invoke · API hashing', tags: [], id: 'h-dinvoke' },
            { title: 'Error Handling', subtitle: 'GetLastError · NTSTATUS · exceptions', tags: [], id: 'h-err' },
          ]
        },
        {
          header: 'PROCESS INJECTION',
          color: 'red',
          nodes: [
            { title: 'Local Injection', subtitle: 'CreateThread · QueueUserAPC · Fiber', tags: [], id: 'h-linj' },
            { title: 'Remote Injection', subtitle: 'CreateRemoteThread · VirtualAllocEx · APC', tags: [], id: 'h-rinj' },
            { title: 'NT Injection', subtitle: 'NtMapViewOfSection · Section Mapping · syscalls', tags: [], id: 'h-ntinj' },
          ]
        },
        {
          header: 'MALWARE',
          color: 'red',
          nodes: [
            { title: 'Injection Primitives', subtitle: 'Process injection · reflective DLL · hollowing', tags: [], id: 'h-malwinj' },
            { title: 'API & Syscalls', subtitle: 'API hashing · IAT hiding · direct & indirect syscalls', tags: [], id: 'h-syscall' },
            { title: 'Evasion', subtitle: 'AMSI · ETW · anti-debug · sandbox detect · entropy', tags: [], id: 'h-malev' },
            { title: 'Loader & Staging', subtitle: 'Loader dev · payload staging · sleep masking · packer', tags: [], id: 'h-loader' },
            { title: 'Stealth', subtitle: 'PPID spoof · arg spoof · NTDLL unhook · DLL sideload · keylogger', tags: [], id: 'h-stealth' },
            { title: 'Build & Sign', subtitle: 'MinGW cross-compile · Authenticode · HWBP evasion', tags: [], id: 'h-build' },
          ]
        },
        {
          header: 'ASR & WDAC',
          color: 'orange',
          nodes: [
            { title: 'ASR', subtitle: 'Rule enumeration · exclusion abuse · bypass', tags: [], id: 'h-asr' },
            { title: 'WDAC', subtitle: 'Policy enum · LOLBAs · trusted signers · filename rules', tags: [], id: 'h-wdac' },
          ]
        },
        {
          header: 'EDR EVASION',
          color: 'blue',
          nodes: [
            { title: 'Hook & Syscall', subtitle: 'Hook detection · direct & indirect syscalls · UDRL', tags: [], id: 'h-hook' },
            { title: 'Implant Evasion', subtitle: 'Sleep mask · stack spoof · UDRL', tags: [], id: 'h-impl' },
            { title: 'Kernel Level', subtitle: 'Kernel callbacks · BYOVD · DKOM', tags: [], id: 'h-kern' },
            { title: 'Vendor Specific', subtitle: 'CrowdStrike · MDE · SentinelOne · Cortex · Elastic · ESET', tags: [], id: 'h-vendor' },
          ]
        },
        {
          header: 'DEVOPS',
          color: 'blue',
          nodes: [
            { title: 'Docker & K8s', subtitle: 'Container escape · RBAC · service accounts', tags: [], id: 'h-docker' },
            { title: 'CI/CD Pipelines', subtitle: 'Jenkins · GitHub Actions · GitLab CI', tags: [], id: 'h-cicd' },
            { title: 'Config Management', subtitle: 'Ansible · Terraform · vault decrypt', tags: [], id: 'h-config' },
            { title: 'Secrets Management', subtitle: 'HashiCorp Vault · AWS SSM · IMDS', tags: [], id: 'h-secrets' },
          ]
        },
        {
          header: 'AI / ML',
          color: 'purple',
          nodes: [
            { title: 'Prompt Injection', subtitle: 'Direct · indirect · jailbreak · system leak', tags: [], id: 'h-prompt' },
            { title: 'LLM Output Attacks', subtitle: 'Markdown inject · exfil · downstream', tags: [], id: 'h-llmout' },
            { title: 'AI Data Attacks', subtitle: 'Training poison · backdoor · RAG poison', tags: [], id: 'h-aidata' },
            { title: 'App & System', subtitle: 'Plugin abuse · agent hijack · supply chain', tags: [], id: 'h-aiapp' },
            { title: 'AI Evasion', subtitle: 'FGSM · PGD · one-pixel · patch attacks', tags: [], id: 'h-aiev' },
            { title: 'AI Privacy', subtitle: 'Membership inference · model inversion · extraction', tags: [], id: 'h-aipriv' },
          ]
        },
      ]));
    }
  } catch {}
}

export default function RedTeamHome() {
  seedIfEmpty();
  return <HomePage pageKey={HOME_KEY} />;
}