// Compatibility shim for old imports.
// The app is fully local-first and no longer uses the Base44 SDK.
export const appBackend = null;
export default null;
